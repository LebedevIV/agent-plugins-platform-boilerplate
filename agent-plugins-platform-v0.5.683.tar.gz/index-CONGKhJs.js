var p = Object.defineProperty;
var w = (u, e, t) => e in u ? p(u, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : u[e] = t;
var i = (u, e, t) => w(u, typeof e != "symbol" ? e + "" : e, t);
var y = {};
class C {
  constructor(e = {}) {
    i(this, "config");
    i(this, "logger");
    i(this, "metricsCollector");
    i(this, "alertManager");
    i(this, "errorTracker");
    i(this, "performanceMonitor");
    i(this, "networkTracker");
    i(this, "isProduction");
    i(this, "traceIdGenerator");
    this.config = {
      enableConsoleLogging: !0,
      enableErrorCapture: !0,
      enablePerformanceMetrics: !0,
      enableMemoryTracking: !0,
      enableNetworkRequestTracking: !0,
      alertThresholds: {
        maxPyodideMemory: 256,
        maxWorkflowDuration: 300,
        maxApiCallDuration: 60,
        maxErrorRate: 10,
        maxConsecutiveFailures: 5
      },
      samplingRates: {
        errorEvents: 1,
        // все ошибки в production
        performanceMetrics: 0.1,
        // 10% метрик для производительности
        networkRequests: 0.5
        // 50% сетевых запросов
      },
      ...e
    }, this.isProduction = y.NODE_ENV === "production", this.traceIdGenerator = () => `trace_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, this.logger = new MonitoringLogger(this.config), this.metricsCollector = new MetricsCollector(this.config, this.logger), this.alertManager = new AlertManager(this.config, this.logger), this.errorTracker = new ErrorTracker(this.config, this.logger, this.alertManager), this.performanceMonitor = new PerformanceMonitor(this.config, this.logger, this.metricsCollector), this.networkTracker = new NetworkTracker(this.config, this.logger, this.metricsCollector), this.initializeGlobalErrorHandlers(), this.logger.addEvent({
      component: "MonitoringCore",
      level: "info",
      message: "Monitoring system initialized",
      data: { config: this.config, isProduction: this.isProduction }
    });
  }
  /**
   * Инициализация глобальных хендлеров ошибок
   */
  initializeGlobalErrorHandlers() {
    this.config.enableErrorCapture && (window.addEventListener("error", (e) => {
      this.captureError("UncaughtError", e.error || new Error(e.message), {
        filename: e.filename,
        lineno: e.lineno,
        colno: e.colno,
        component: "global"
      });
    }), window.addEventListener("unhandledrejection", (e) => {
      this.captureError("UnhandledRejection", new Error(e.reason), {
        component: "promise",
        originalReason: e.reason
      });
    }));
  }
  /**
   * Захват и обработка ошибки
   */
  captureError(e, t, r) {
    const s = this.traceIdGenerator(), o = {
      context: e,
      timestamp: Date.now(),
      traceId: s,
      stack: t.stack,
      component: (r == null ? void 0 : r.component) || "unknown",
      userAgent: navigator.userAgent,
      url: window.location.href,
      ...r
    };
    this.errorTracker.trackError(t, o), this.metricsCollector.incrementCounter("errors_total", {
      component: o.component,
      context: e,
      level: "error"
    }), (o.component === "pyodide" || o.component === "workflow") && this.alertManager.createAlert({
      id: `error_${Date.now()}`,
      severity: "high",
      component: o.component,
      message: `Критическая ошибка в ${e}: ${t.message}`,
      timestamp: Date.now(),
      acknowledged: !1,
      resolved: !1
    });
  }
  /**
   * Измерение производительности операции
   */
  async measurePerformance(e, t, r) {
    const s = performance.now(), o = this.traceIdGenerator();
    try {
      const n = await t(), a = performance.now() - s;
      return this.shouldSample("performanceMetrics") && (this.performanceMonitor.recordOperation(e, a, {
        ...r,
        traceId: o,
        success: !0
      }), this.metricsCollector.recordHistogram("operation_duration_seconds", a / 1e3, {
        operation: e,
        ...r
      })), n;
    } catch (n) {
      const a = performance.now() - s;
      throw this.performanceMonitor.recordOperation(e, a, {
        ...r,
        traceId: o,
        success: !1,
        error: n.message
      }), this.metricsCollector.recordHistogram("operation_duration_seconds", a / 1e3, {
        operation: e,
        success: "false",
        ...r
      }), n;
    }
  }
  /**
   * Отслеживание сетевых запросов
   */
  trackNetworkRequest(e, t, r, s, o) {
    !this.config.enableNetworkRequestTracking || !this.shouldSample("networkRequests") || (this.networkTracker.trackRequest({
      url: e,
      method: t,
      responseTime: r,
      statusCode: s,
      success: o,
      timestamp: Date.now()
    }), s && s >= 400 && this.metricsCollector.incrementCounter("http_errors_total", {
      status_code: s.toString(),
      method: t,
      component: "network"
    }));
  }
  /**
   * Отслеживание использования памяти Pyodide
   */
  trackPyodideMemory(e, t) {
    this.config.enableMemoryTracking && (this.metricsCollector.recordGauge("pyodide_memory_used_mb", e, {
      component: "pyodide"
    }), t && this.metricsCollector.recordGauge("pyodide_memory_total_mb", t, {
      component: "pyodide"
    }), e > this.config.alertThresholds.maxPyodideMemory && this.alertManager.createAlert({
      id: `memory_${Date.now()}`,
      severity: "medium",
      component: "pyodide",
      message: `Высокое использование памяти Pyodide: ${e.toFixed(2)}MB`,
      timestamp: Date.now(),
      acknowledged: !1,
      resolved: !1,
      threshold: {
        metric: "pyodide_memory_used_mb",
        operator: ">",
        value: this.config.alertThresholds.maxPyodideMemory,
        duration: 60
      }
    }));
  }
  /**
   * Регистрация пользовательского события
   */
  addLog(e, t, r, s) {
    const o = (s == null ? void 0 : s.traceId) || this.traceIdGenerator();
    this.logger.addEvent({
      timestamp: Date.now(),
      component: e,
      level: t,
      message: r,
      data: s,
      traceId: o
    });
  }
  /**
   * Проверка сэмплинга для разных типов событий
   */
  shouldSample(e) {
    return this.isProduction ? Math.random() < this.config.samplingRates[e] : !0;
  }
  /**
   * Получение общего здоровья системы
   */
  getHealthStatus() {
    const e = this.alertManager.getActiveAlerts(), t = e.filter(
      (n) => n.severity === "critical"
      /* CRITICAL */
    ), r = e.filter(
      (n) => n.severity === "high"
      /* HIGH */
    );
    let s = "healthy", o = [];
    return t.length > 0 ? (s = "unhealthy", o = t.map((n) => n.message)) : r.length > 3 && (s = "degraded", o = r.slice(0, 3).map((n) => n.message)), this.errorTracker.getErrorRate() > this.config.alertThresholds.maxErrorRate && (s = "degraded", o.push(`Высокий уровень ошибок: ${this.errorTracker.getErrorRate().toFixed(2)}%`)), {
      status: s,
      issues: o,
      lastUpdate: Date.now()
    };
  }
  // Геттеры для доступа к компонентам
  getLogger() {
    return this.logger;
  }
  getMetricsCollector() {
    return this.metricsCollector;
  }
  getAlertManager() {
    return this.alertManager;
  }
  getErrorTracker() {
    return this.errorTracker;
  }
  getPerformanceMonitor() {
    return this.performanceMonitor;
  }
  getNetworkTracker() {
    return this.networkTracker;
  }
  // Метод для корректного завершения работы
  dispose() {
    this.logger.addEvent({
      component: "MonitoringCore",
      level: "info",
      message: "Monitoring system disposed",
      data: {}
    }), window && (window.removeEventListener("error", this.captureError.bind(this)), window.removeEventListener("unhandledrejection", this.captureError.bind(this)));
  }
}
let g = null;
function M(u) {
  return g || (g = new C(u)), g;
}
var v = {};
let A = class {
  constructor(e) {
    i(this, "config");
    i(this, "logBuffer");
    i(this, "bufferSize", 1e3);
    i(this, "isEnabled", !0);
    i(this, "consolePrefix", "[Monitoring]");
    this.config = e, this.logBuffer = [], this.setupConsoleOverrides();
  }
  /**
   * Добавление события в лог
   */
  addEvent(e) {
    const t = {
      ...e,
      sessionId: this.getSessionId(),
      userId: this.getUserId(),
      environment: v.NODE_ENV || "development",
      version: "1.0.0"
    };
    this.logBuffer.push(t), this.logBuffer.length > this.bufferSize && (this.logBuffer = this.logBuffer.slice(-this.bufferSize)), this.config.enableConsoleLogging && this.isEnabled && this.logToConsole(t), this.persistLog(t);
  }
  /**
   * Удобные методы для разных уровней логирования
   */
  debug(e, t, r) {
    this.addEvent({
      component: e,
      level: LogLevel.DEBUG,
      message: t,
      data: r,
      timestamp: Date.now()
    });
  }
  info(e, t, r) {
    this.addEvent({
      component: e,
      level: LogLevel.INFO,
      message: t,
      data: r,
      timestamp: Date.now()
    });
  }
  warn(e, t, r) {
    this.addEvent({
      component: e,
      level: LogLevel.WARN,
      message: t,
      data: r,
      timestamp: Date.now()
    });
  }
  error(e, t, r, s) {
    this.addEvent({
      component: e,
      level: LogLevel.ERROR,
      message: t,
      error: r,
      data: s,
      timestamp: Date.now()
    });
  }
  critical(e, t, r, s) {
    this.addEvent({
      component: e,
      level: LogLevel.CRITICAL,
      message: t,
      error: r,
      data: s,
      timestamp: Date.now()
    });
  }
  /**
   * Получение логов с фильтрацией
   */
  getLogs(e) {
    let t = [...this.logBuffer];
    return e && (e.component && (t = t.filter((r) => r.component === e.component)), e.level && (t = t.filter((r) => r.level === e.level)), e.fromTime && (t = t.filter((r) => r.timestamp >= e.fromTime)), e.toTime && (t = t.filter((r) => r.timestamp <= e.toTime)), e.limit && (t = t.slice(-e.limit))), t;
  }
  /**
   * Получение статистики по логам
   */
  getLogStats() {
    const e = {
      [LogLevel.DEBUG]: 0,
      [LogLevel.INFO]: 0,
      [LogLevel.WARN]: 0,
      [LogLevel.ERROR]: 0,
      [LogLevel.CRITICAL]: 0
    }, t = {};
    let r = 1 / 0, s = 0;
    return this.logBuffer.forEach((o) => {
      e[o.level]++, t[o.component] = (t[o.component] || 0) + 1, r = Math.min(r, o.timestamp), s = Math.max(s, o.timestamp);
    }), {
      total: this.logBuffer.length,
      byLevel: e,
      byComponent: t,
      timeRange: {
        from: r === 1 / 0 ? 0 : r,
        to: s === 0 ? Date.now() : s
      }
    };
  }
  /**
   * Экспорт логов в разных форматах
   */
  exportLogs(e = {
    format: "json",
    includeStackTraces: !0,
    maxEntries: 500,
    timeFormat: "iso"
  }) {
    const t = this.getLogs({ limit: e.maxEntries });
    switch (e.format) {
      case "json":
        return JSON.stringify(t, null, 2);
      case "csv":
        const r = ["timestamp", "level", "component", "message", "data", "error"], s = t.map((o) => {
          var n;
          return [
            e.timeFormat === "iso" ? new Date(o.timestamp).toISOString() : o.timestamp.toString(),
            o.level,
            o.component,
            o.message,
            JSON.stringify(o.data || {}),
            e.includeStackTraces && ((n = o.error) == null ? void 0 : n.stack) || ""
          ];
        });
        return [r, ...s].map((o) => o.map((n) => `"${n}"`).join(",")).join(`
`);
      case "text":
        return t.map((o) => this.formatLogForText(o, e)).join(`
`);
      default:
        throw new Error(`Unsupported format: ${e.format}`);
    }
  }
  /**
   * Очистка всех логов
   */
  clearLogs() {
    this.logBuffer = [], this.clearPersistedLogs();
  }
  /**
   * Временное отключение логирования
   */
  disable() {
    this.isEnabled = !1;
  }
  /**
   * Включение логирования
   */
  enable() {
    this.isEnabled = !0;
  }
  // ===== PRIVATE METHODS =====
  /**
   * Переопределение console методов для захвата
   */
  setupConsoleOverrides() {
    const e = { ...console };
    ["log", "info", "warn", "error"].forEach((t) => {
      console[t] && (console[t] = (...r) => {
        const s = r.map(
          (o) => typeof o == "object" ? JSON.stringify(o) : String(o)
        ).join(" ");
        this.addEvent({
          component: "console",
          level: t === "warn" ? LogLevel.WARN : t === "error" ? LogLevel.ERROR : LogLevel.INFO,
          message: `[${t.uppercase()}] ${s}`,
          timestamp: Date.now()
        }), e[t](...r);
      });
    });
  }
  /**
   * Логирование в console с цветовым кодированием
   */
  logToConsole(e) {
    const t = new Date(e.timestamp).toISOString().split("T")[1].slice(0, 8), r = `${this.consolePrefix}[${t}][${e.component}][${e.level.toUpperCase()}]`;
    switch (e.level) {
      case LogLevel.DEBUG:
        console.debug(`%c${r} ${e.message}`, "color: #666; font-size: 10px;");
        break;
      case LogLevel.INFO:
        console.info(`%c${r} ${e.message}`, "color: #0066cc; font-weight: bold;");
        break;
      case LogLevel.WARN:
        console.warn(`%c${r} ${e.message}`, "color: #ff8c00; font-weight: bold;");
        break;
      case LogLevel.ERROR:
      case LogLevel.CRITICAL:
        console.error(`%c${r} ${e.message}`, "color: #cc0000; font-weight: bold;"), e.error && console.error(e.error);
        break;
    }
    e.data && Object.keys(e.data).length > 0 && console.log("Additional data:", e.data);
  }
  /**
   * Форматирование лога для текстового экспорта
   */
  formatLogForText(e, t) {
    var o;
    let s = `[${t.timeFormat === "iso" ? new Date(e.timestamp).toISOString() : e.timestamp.toString()}] [${e.level.toUpperCase()}] [${e.component}]: ${e.message}`;
    return e.data && Object.keys(e.data).length > 0 && (s += `
  Data: ${JSON.stringify(e.data, null, 2)}`), t.includeStackTraces && ((o = e.error) != null && o.stack) && (s += `
  Stack: ${e.error.stack}`), s;
  }
  /**
   * Сохранение логов в chrome.storage (для persistence через перезапуски)
   */
  persistLog(e) {
    var t;
    try {
      if (typeof chrome < "u" && ((t = chrome.storage) != null && t.local)) {
        const r = "monitoring_logs";
        chrome.storage.local.get([r]).then((s) => {
          const o = s[r] || [];
          o.push(e);
          const n = o.slice(-1e3);
          chrome.storage.local.set({ [r]: n });
        });
      }
    } catch {
    }
  }
  /**
   * Очистка сохраненных логов
   */
  clearPersistedLogs() {
    var e;
    try {
      typeof chrome < "u" && ((e = chrome.storage) != null && e.local) && chrome.storage.local.remove(["monitoring_logs"]);
    } catch {
    }
  }
  /**
   * Получение Id сессии
   */
  getSessionId() {
    var e;
    try {
      if (typeof chrome < "u" && ((e = chrome.storage) != null && e.session)) {
        const t = "monitoring_session_id";
        chrome.storage.session.get([t]).then((r) => {
          if (!r[t]) {
            const s = Math.random().toString(36).substring(2, 15);
            return chrome.storage.session.set({ [t]: s }), s;
          }
          return r[t];
        });
      }
    } catch {
    }
    return `session_${Date.now()}`;
  }
  /**
   * Получение Id пользователя (анонимизированный)
   */
  getUserId() {
    var e;
    try {
      if (typeof chrome < "u" && ((e = chrome.storage) != null && e.local)) {
        const t = "monitoring_user_id";
        chrome.storage.local.get([t]).then((r) => {
          if (!r[t]) {
            const s = `user_${Math.random().toString(36).substring(2, 15)}`;
            return chrome.storage.local.set({ [t]: s }), s;
          }
          return r[t];
        });
      }
    } catch {
    }
    return "anonymous_user";
  }
};
const k = [
  { le: 0.1, name: "0.1s" },
  { le: 0.5, name: "0.5s" },
  { le: 1, name: "1s" },
  { le: 2.5, name: "2.5s" },
  { le: 5, name: "5s" },
  { le: 10, name: "10s" },
  { le: 25, name: "25s" },
  { le: 60, name: "60s" },
  { le: 300, name: "300s" }
];
let _ = class {
  constructor(e, t) {
    i(this, "config");
    i(this, "logger");
    // Хранение метрик в памяти
    i(this, "counters", /* @__PURE__ */ new Map());
    // name -> labels -> value
    i(this, "gauges", /* @__PURE__ */ new Map());
    // name -> labels -> value
    i(this, "histograms", /* @__PURE__ */ new Map());
    // name -> labels -> histogram_data
    i(this, "maxHistogramSamples", 1e3);
    this.config = e, this.logger = t, this.initializeDefaultMetrics();
  }
  /**
   * Инкремент счетчика
   */
  incrementCounter(e, t = {}, r = 1) {
    const s = this.getLabelsKey(t), o = this.counters.get(e) || /* @__PURE__ */ new Map(), n = o.get(s) || 0;
    o.set(s, n + r), this.counters.set(e, o), this.logger.debug("MetricsCollector", `Counter incremented: ${e}`, {
      labels: t,
      value: r,
      newValue: n + r
    });
  }
  /**
   * Установка значения gauge
   */
  recordGauge(e, t, r = {}) {
    const s = this.getLabelsKey(r), o = this.gauges.get(e) || /* @__PURE__ */ new Map();
    o.set(s, t), this.gauges.set(e, o), this.checkGaugeThreshold(e, t, r);
  }
  /**
   * Добавление значения в гистограмму
   */
  recordHistogram(e, t, r = {}) {
    const s = this.getLabelsKey(r), o = this.histograms.get(e) || /* @__PURE__ */ new Map(), n = o.get(s) || {
      count: 0,
      sum: 0,
      min: 1 / 0,
      max: -1 / 0,
      values: [],
      buckets: {}
    };
    n.count++, n.sum += t, n.min = Math.min(n.min, t), n.max = Math.max(n.max, t), n.values.push(t), n.values.length > this.maxHistogramSamples && (n.values = n.values.slice(-this.maxHistogramSamples)), this.updateBuckets(n.buckets, t), o.set(s, n), this.histograms.set(e, o);
  }
  /**
   * Добавление значения таймера (специальный случай гистограммы для измерения времени)
   */
  recordTimer(e, t, r = {}) {
    const s = performance.now() - t;
    this.recordHistogram(e, s / 1e3, r);
  }
  /**
   * Получение статистики по всем метрикам
   */
  getMetricsStats() {
    const e = {
      counters: {},
      gauges: {},
      histograms: {},
      lastUpdate: Date.now()
    };
    return this.counters.forEach((t, r) => {
      e.counters[r] = Array.from(t.values()).reduce((s, o) => s + o, 0);
    }), this.gauges.forEach((t, r) => {
      e.gauges[r] = Array.from(t.values()).pop() || 0;
    }), this.histograms.forEach((t, r) => {
      const s = [], o = { count: 0, sum: 0, min: 1 / 0, max: -1 / 0 };
      t.forEach((n) => {
        o.count += n.count, o.sum += n.sum, o.min = Math.min(o.min, n.min), o.max = Math.max(o.max, n.max), s.push(...n.values);
      }), s.length > 0 && (e.histograms[r] = {
        count: o.count,
        sum: o.sum,
        min: o.min === 1 / 0 ? 0 : o.min,
        max: o.max === -1 / 0 ? 0 : o.max,
        avg: o.sum / o.count,
        percentiles: this.calculatePercentiles(s),
        buckets: this.mergeBuckets(t)
      });
    }), e;
  }
  /**
   * Получение конкретной метрики
   */
  getMetric(e, t) {
    const r = t ? this.getLabelsKey(t) : "", s = this.counters.get(e);
    if (s) {
      const a = r ? s.get(r) : Array.from(s.values()).reduce((l, m) => l + m, 0);
      if (a !== void 0)
        return {
          name: e,
          type: MetricType.COUNTER,
          value: a,
          labels: t,
          timestamp: Date.now()
        };
    }
    const o = this.gauges.get(e);
    if (o) {
      const a = r ? o.get(r) : Array.from(o.values()).pop();
      if (a !== void 0)
        return {
          name: e,
          type: MetricType.GAUGE,
          value: a,
          labels: t,
          timestamp: Date.now()
        };
    }
    const n = this.histograms.get(e);
    if (n) {
      const a = r ? n.get(r) : Array.from(n.values())[0];
      if (a)
        return {
          name: e,
          type: MetricType.HISTOGRAM,
          value: a.sum / a.count,
          labels: t,
          timestamp: Date.now()
        };
    }
    return null;
  }
  /**
   * Очистка всех метрик
   */
  clearMetrics() {
    this.counters.clear(), this.gauges.clear(), this.histograms.clear(), this.initializeDefaultMetrics(), this.logger.info("MetricsCollector", "All metrics cleared");
  }
  /**
   * Экспорт метрик в Prometheus-формате
   */
  exportPrometheusFormat() {
    const e = [], t = this.getMetricsStats();
    return Object.entries(t.counters).forEach(([r, s]) => {
      e.push(`# HELP ${r} Counter metric`), e.push(`# TYPE ${r} counter`), e.push(`${r}_total ${s}`);
    }), Object.entries(t.gauges).forEach(([r, s]) => {
      e.push(`# HELP ${r} Gauge metric`), e.push(`# TYPE ${r} gauge`), e.push(`${r} ${s}`);
    }), Object.entries(t.histograms).forEach(([r, s]) => {
      e.push(`# HELP ${r} Histogram metric`), e.push(`# TYPE ${r} histogram`), Object.entries(s.buckets).forEach(([o, n]) => {
        e.push(`${r}_bucket{le="${o}"} ${n}`);
      }), e.push(`${r}_count ${s.count}`), e.push(`${r}_sum ${s.sum}`);
    }), e.join(`
`);
  }
  // ===== PRIVATE METHODS =====
  /**
   * Инициализация метрик по умолчанию
   */
  initializeDefaultMetrics() {
    this.incrementCounter("monitoring_system_startups", {}, 0), this.recordGauge("monitoring_buffer_size", this.counters.size);
  }
  /**
   * Получение ключа для labels (сортированный)
   */
  getLabelsKey(e) {
    return Object.keys(e).sort().map((t) => `${t}="${e[t]}"`).join(",");
  }
  /**
   * Обновление buckets для гистограммы
   */
  updateBuckets(e, t) {
    k.forEach((s) => {
      if (t <= s.le) {
        const o = e[s.le.toString()] || 0;
        e[s.le.toString()] = o + 1;
      }
    });
    const r = e["+Inf"] || 0;
    e["+Inf"] = r + 1;
  }
  /**
   * Расчет перцентилей
   */
  calculatePercentiles(e) {
    if (e.length === 0) return {};
    const t = [...e].sort((s, o) => s - o);
    return [50, 75, 90, 95, 99].reduce((s, o) => {
      const n = Math.ceil(o / 100 * t.length) - 1;
      return s[`p${o}`] = t[n] || 0, s;
    }, {});
  }
  /**
   * Слияние buckets из разных label комбинаций
   */
  mergeBuckets(e) {
    const t = {};
    return e.forEach((r) => {
      Object.entries(r.buckets).forEach(([s, o]) => {
        t[s] = (t[s] || 0) + o;
      });
    }), t;
  }
  /**
   * Проверка порогов для gauge метрик
   */
  checkGaugeThreshold(e, t, r) {
    switch (e) {
      case "pyodide_memory_used_mb":
        t > this.config.alertThresholds.maxPyodideMemory && this.logger.warn("MetricsCollector", "Pyodide memory usage exceeded threshold", {
          current: t,
          threshold: this.config.alertThresholds.maxPyodideMemory,
          labels: r
        });
        break;
      case "workflow_duration_seconds":
        t > this.config.alertThresholds.maxWorkflowDuration && this.logger.error("MetricsCollector", "Workflow duration exceeded threshold", {
          current: t,
          threshold: this.config.alertThresholds.maxWorkflowDuration,
          labels: r
        });
        break;
      case "ai_api_call_duration_seconds":
        t > this.config.alertThresholds.maxApiCallDuration && this.logger.warn("MetricsCollector", "AI API call duration exceeded threshold", {
          current: t,
          threshold: this.config.alertThresholds.maxApiCallDuration,
          labels: r
        });
        break;
    }
  }
}, S = class {
  // alertType -> lastFired
  constructor(e, t) {
    i(this, "config");
    i(this, "logger");
    i(this, "alerts", []);
    i(this, "alertRules", []);
    i(this, "nextAlertId", 1);
    i(this, "alertCooldown", /* @__PURE__ */ new Map());
    this.config = e, this.logger = t, this.initializeDefaultRules();
  }
  /**
   * Создание нового алерта
   */
  createAlert(e) {
    if (this.isAlertOnCooldown(e.component, e.severity))
      return this.logger.debug("AlertManager", "Alert suppressed due to cooldown", {
        component: e.component,
        severity: e.severity
      }), "";
    const t = {
      ...e,
      id: `alert_${this.nextAlertId++}`,
      timestamp: Date.now(),
      acknowledged: !1,
      resolved: !1
    }, r = this.findSimilarActiveAlert(e);
    return r ? (this.logger.debug("AlertManager", "Similar alert already exists, updating instead", {
      existingId: r.id,
      newId: t.id
    }), r.message = e.message, r.timestamp = t.timestamp, r.id) : (this.alerts.push(t), this.updateAlertCooldown(t.component, t.severity), this.logger.warn("AlertManager", `Alert created: ${e.severity}`, {
      id: t.id,
      component: e.component,
      message: e.message,
      severity: e.severity
    }), (e.severity === AlertSeverity.CRITICAL || e.severity === AlertSeverity.HIGH) && this.notifyCriticalAlert(t), t.id);
  }
  /**
   * Разрешение алерта
   */
  resolveAlert(e, t) {
    const r = this.alerts.find((s) => s.id === e);
    return !r || r.resolved ? !1 : (r.resolved = !0, r.acknowledged = !0, this.logger.info("AlertManager", "Alert resolved", {
      id: e,
      component: r.component,
      resolvedBy: t || "system"
    }), (r.severity === AlertSeverity.CRITICAL || r.severity === AlertSeverity.HIGH) && this.notifyAlertResolved(r), !0);
  }
  /**
   * Подтверждение алерта (без разрешения)
   */
  acknowledgeAlert(e, t) {
    const r = this.alerts.find((s) => s.id === e);
    return !r || r.acknowledged ? !1 : (r.acknowledged = !0, this.logger.info("AlertManager", "Alert acknowledged", {
      id: e,
      acknowledgedBy: t || "system"
    }), !0);
  }
  /**
   * Получение всех алертов
   */
  getAlerts(e) {
    let t = [...this.alerts];
    return e && (e.component && (t = t.filter((r) => r.component === e.component)), e.severity && (t = t.filter((r) => r.severity === e.severity)), e.fromTime && (t = t.filter((r) => r.timestamp >= e.fromTime)), e.acknowledged !== void 0 && (t = t.filter((r) => r.acknowledged === e.acknowledged)), e.resolved !== void 0 && (t = t.filter((r) => r.resolved === e.resolved))), t.sort((r, s) => s.timestamp - r.timestamp);
  }
  /**
   * Получение активных алертов (не разрешенных, критичных)
   */
  getActiveAlerts() {
    return this.alerts.filter((e) => !e.resolved && (e.severity === AlertSeverity.CRITICAL || e.severity === AlertSeverity.HIGH));
  }
  /**
   * Получение статистики по алертам
   */
  getAlertStats() {
    const e = {
      [AlertSeverity.LOW]: 0,
      [AlertSeverity.MEDIUM]: 0,
      [AlertSeverity.HIGH]: 0,
      [AlertSeverity.CRITICAL]: 0
    }, t = {};
    this.alerts.forEach((n) => {
      e[n.severity]++, t[n.component] = (t[n.component] || 0) + 1;
    });
    const r = this.getActiveAlerts().length, s = this.alerts.filter((n) => n.acknowledged).length, o = this.alerts.filter((n) => n.resolved).length;
    return {
      total: this.alerts.length,
      bySeverity: e,
      byComponent: t,
      active: r,
      acknowledged: s,
      resolved: o
    };
  }
  /**
   * Создание алерта на основе правила
   */
  triggerAlertForRule(e, t, r = {}) {
    this.findMatchingRules(e, t).forEach((o) => {
      this.shouldTriggerDefaultAlert(e, t) && this.createAlert({
        severity: o.severity,
        component: r.component || "unknown",
        message: this.generateAlertMessage(e, t, o),
        threshold: o.condition
      });
    });
  }
  /**
   * Добавление пользовательского правила алертов
   */
  addAlertRule(e) {
    const t = `rule_${this.alertRules.length + 1}`, r = {
      ...e,
      id: t
    };
    return this.alertRules.push(r), this.logger.info("AlertManager", "Alert rule added", {
      ruleId: t,
      name: e.name,
      metric: e.condition.metric
    }), t;
  }
  /**
   * Очистка старых разрешенных алертов
   */
  cleanupResolvedAlerts(e = 10080 * 60 * 1e3) {
    const t = Date.now() - e, r = this.alerts.length;
    this.alerts = this.alerts.filter(
      (o) => !o.resolved || o.timestamp > t
    );
    const s = r - this.alerts.length;
    return s > 0 && this.logger.debug("AlertManager", `Cleaned up ${s} resolved alerts`), s;
  }
  // ===== PRIVATE METHODS =====
  /**
   * Инициализация правил алертов по умолчанию
   */
  initializeDefaultRules() {
    this.addAlertRule({
      name: "Pyodide Memory Usage",
      description: "High Pyodide memory usage detected",
      condition: {
        metric: "pyodide_memory_used_mb",
        operator: ">",
        threshold: this.config.alertThresholds.maxPyodideMemory,
        duration: 300
        // 5 минут
      },
      severity: AlertSeverity.MEDIUM,
      enabled: !0,
      tags: ["memory", "pyodide"]
    }), this.addAlertRule({
      name: "Workflow Duration Timeout",
      description: "Workflow taking too long to complete",
      condition: {
        metric: "workflow_duration_seconds",
        operator: ">",
        threshold: this.config.alertThresholds.maxWorkflowDuration,
        duration: 60
        // 1 минута
      },
      severity: AlertSeverity.HIGH,
      enabled: !0,
      tags: ["workflow", "timeout"]
    }), this.addAlertRule({
      name: "AI API Failure Rate",
      description: "High failure rate in AI API calls",
      condition: {
        metric: "ai_api_errors_rate",
        operator: ">",
        threshold: this.config.alertThresholds.maxErrorRate / 100,
        duration: 600
        // 10 минут
      },
      severity: AlertSeverity.HIGH,
      enabled: !0,
      tags: ["ai", "api", "errors"]
    }), this.addAlertRule({
      name: "Consecutive Failures",
      description: "Too many consecutive failures detected",
      condition: {
        metric: "consecutive_failures",
        operator: ">=",
        threshold: this.config.alertThresholds.maxConsecutiveFailures,
        duration: 3600
        // 1 час
      },
      severity: AlertSeverity.CRITICAL,
      enabled: !0,
      tags: ["failures", "critical"]
    });
  }
  /**
   * Поиск похожих активных алертов
   */
  findSimilarActiveAlert(e) {
    const r = Date.now();
    return this.alerts.find(
      (s) => !s.resolved && s.component === e.component && s.severity === e.severity && Math.abs(s.timestamp - r) < 3e5
    ) || null;
  }
  /**
   * Проверка cooldown для алертов
   */
  isAlertOnCooldown(e, t) {
    const r = `${e}_${t}`, s = this.alertCooldown.get(r), o = this.getCooldownTime(t);
    return s ? Date.now() - s < o : !1;
  }
  /**
   * Обновление cooldown для алерта
   */
  updateAlertCooldown(e, t) {
    const r = `${e}_${t}`;
    this.alertCooldown.set(r, Date.now());
  }
  /**
   * Получение времени cooldown в зависимости от severity
   */
  getCooldownTime(e) {
    switch (e) {
      case AlertSeverity.LOW:
        return 120 * 1e3;
      // 2 минуты
      case AlertSeverity.MEDIUM:
        return 300 * 1e3;
      // 5 минут
      case AlertSeverity.HIGH:
        return 600 * 1e3;
      // 10 минут
      case AlertSeverity.CRITICAL:
        return 1800 * 1e3;
      // 30 минут
      default:
        return 300 * 1e3;
    }
  }
  /**
   * Генерация сообщения для алерта
   */
  generateAlertMessage(e, t, r) {
    const s = r.condition.threshold, o = s > t ? "below" : "above";
    return `${r.name}: Value ${o} threshold (${t.toFixed(2)} vs ${s}) for metric ${e}`;
  }
  /**
   * Поиск подходящих правил для метрики
   */
  findMatchingRules(e, t) {
    return this.alertRules.filter(
      (r) => r.enabled && r.condition.metric === e && this.evaluateCondition(t, r.condition.operator, r.condition.threshold)
    );
  }
  /**
   * Оценка условия алерта
   */
  evaluateCondition(e, t, r) {
    switch (t) {
      case ">":
        return e > r;
      case "<":
        return e < r;
      case ">=":
        return e >= r;
      case "<=":
        return e <= r;
      case "==":
        return e === r;
      case "!=":
        return e !== r;
      default:
        return !1;
    }
  }
  /**
   * Проверка, следует ли создавать алерт по умолчанию для известной метрики
   */
  shouldTriggerDefaultAlert(e, t) {
    switch (e) {
      case "pyodide_memory_used_mb":
        return t > this.config.alertThresholds.maxPyodideMemory;
      case "workflow_duration_seconds":
        return t > this.config.alertThresholds.maxWorkflowDuration;
      case "ai_api_errors_rate":
        return t > this.config.alertThresholds.maxErrorRate / 100;
      case "consecutive_failures":
        return t >= this.config.alertThresholds.maxConsecutiveFailures;
      default:
        return !0;
    }
  }
  /**
   * Уведомление о критическом алерте
   */
  notifyCriticalAlert(e) {
    this.logger.error("AlertManager", "CRITICAL ALERT TRIGGERED", {
      id: e.id,
      component: e.component,
      message: e.message,
      severity: e.severity
    });
  }
  /**
   * Уведомление о разрешении алерта
   */
  notifyAlertResolved(e) {
    this.logger.info("AlertManager", "Alert resolved notification", {
      id: e.id,
      component: e.component,
      message: e.message,
      resolvedAt: Date.now(),
      duration: Date.now() - e.timestamp
    });
  }
}, $ = class {
  constructor(e, t, r) {
    i(this, "config");
    i(this, "logger");
    i(this, "alertManager");
    i(this, "errorPatterns", /* @__PURE__ */ new Map());
    i(this, "errorCounts", /* @__PURE__ */ new Map());
    i(this, "errorRateSlidingWindow", []);
    // ошибки за последние N минут
    i(this, "windowSize", 10);
    // 10 минут
    i(this, "maxErrorSamplesPerPattern", 5);
    this.config = e, this.logger = t, this.alertManager = r;
  }
  /**
   * Отслеживание отдельной ошибки
   */
  trackError(e, t = {}) {
    const r = t.component || "unknown", s = Date.now(), o = t.traceId || this.generateTraceId(), n = {
      timestamp: s,
      component: r,
      message: e.message,
      error: e,
      data: t,
      frequency: 1,
      traceId: o
    }, a = r, l = this.errorCounts.get(a);
    l ? (l.count++, l.lastSeen = s, n.frequency = l.count) : this.errorCounts.set(a, { count: 1, lastSeen: s });
    const m = this.analyzeErrorPattern(e, r);
    return m && this.updateErrorPattern(m, e.message, t), this.updateErrorRateWindow(s), this.checkErrorAlertTriggers(r, n), this.logger.error(r, e.message, e, t), n;
  }
  /**
   * Получение оценки уровня ошибок (процент ошибок)
   */
  getErrorRate() {
    const e = this.errorRateSlidingWindow.length;
    return e === 0 ? 0 : e / (e + 1e3) * 100;
  }
  /**
   * Получение самых частых паттернов ошибок
   */
  getTopErrorPatterns(e = 10) {
    return Array.from(this.errorPatterns.values()).sort((t, r) => r.count - t.count).slice(0, e);
  }
  /**
   * Получение статистики ошибок
   */
  getErrorStats() {
    const e = {};
    this.errorCounts.forEach((o, n) => {
      e[n] = o.count;
    });
    const t = Array.from(this.errorCounts.values()).map((o) => o.lastSeen), r = t.length > 0 ? Math.min(...t) : 0, s = t.length > 0 ? Math.max(...t) : Date.now();
    return {
      totalErrors: Array.from(this.errorCounts.values()).reduce((o, n) => o + n.count, 0),
      errorRate: this.getErrorRate(),
      topPatterns: this.getTopErrorPatterns(5),
      byComponent: e,
      recentErrors: [],
      // Можно реализовать если нужно
      timeRange: { from: r, to: s }
    };
  }
  /**
   * Очистка старых счетчиков ошибок
   */
  cleanup(e = 1440 * 60 * 1e3) {
    const t = Date.now() - e;
    let r = 0;
    for (const [s, o] of this.errorCounts.entries())
      o.lastSeen < t && (this.errorCounts.delete(s), r++);
    for (const [s, o] of this.errorPatterns.entries())
      o.lastSeen < t && (this.errorPatterns.delete(s), r++);
    return r > 0 && this.logger.debug("ErrorTracker", `Cleaned up ${r} old error records`), r;
  }
  // ===== PRIVATE METHODS =====
  /**
   * Гнерация уникального ID трассировки
   */
  generateTraceId() {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  /**
   * Анализ паттерна ошибки
   */
  analyzeErrorPattern(e, t) {
    let r = "";
    if (e.message && (r += e.message.slice(0, 100)), e.stack) {
      const s = e.stack.split(`
`).slice(0, 3);
      r += " | " + s.join(" | ");
    }
    return `${t}:${r}`.slice(0, 200);
  }
  /**
   * Обновление паттерна ошибки
   */
  updateErrorPattern(e, t, r) {
    const s = this.errorPatterns.get(e);
    if (s)
      s.count++, s.lastSeen = Date.now(), !s.examples.includes(t) && s.examples.length < this.maxErrorSamplesPerPattern && s.examples.push(t), s.severity = this.calculateSeverity(s.count);
    else {
      const o = {
        id: `pattern_${e.replace(/[^a-zA-Z0-9]/g, "_").slice(0, 50)}`,
        signature: e,
        count: 1,
        firstSeen: Date.now(),
        lastSeen: Date.now(),
        component: r.component || "unknown",
        severity: "low",
        examples: t.length > 0 ? [t] : [],
        tags: this.extractErrorTags(t)
      };
      this.errorPatterns.set(e, o);
    }
  }
  /**
   * Обновление окна для расчета частоты ошибок
   */
  updateErrorRateWindow(e) {
    this.errorRateSlidingWindow.push(e);
    const t = e - this.windowSize * 60 * 1e3;
    this.errorRateSlidingWindow = this.errorRateSlidingWindow.filter((r) => r >= t), this.errorRateSlidingWindow.length > 1e3 && (this.errorRateSlidingWindow = this.errorRateSlidingWindow.slice(-1e3));
  }
  /**
   * Проверка необходимости создания алертов на основе ошибок
   */
  checkErrorAlertTriggers(e, t) {
    const r = this.errorCounts.get(e);
    r && (r.count >= this.config.alertThresholds.maxConsecutiveFailures && this.alertManager.createAlert({
      severity: AlertSeverity.HIGH,
      component: "error_tracker",
      message: `High consecutive error rate in ${e}: ${r.count} errors`,
      threshold: {
        metric: "consecutive_failures",
        operator: ">=",
        value: this.config.alertThresholds.maxConsecutiveFailures,
        duration: 3600
      }
    }), this.getErrorRate() > this.config.alertThresholds.maxErrorRate && this.alertManager.createAlert({
      severity: AlertSeverity.MEDIUM,
      component: e,
      message: `Error rate exceeded threshold: ${this.getErrorRate().toFixed(2)}%`,
      threshold: {
        metric: "error_rate",
        operator: ">",
        value: this.config.alertThresholds.maxErrorRate,
        duration: 600
      }
    }), e === "pyodide" && r.count > 3 && this.alertManager.createAlert({
      severity: AlertSeverity.CRITICAL,
      component: "pyodide",
      message: `Multiple Pyodide errors detected: ${r.count} errors in recent timeframe`
    }));
  }
  /**
   * Расчет уровня серьезности на основе количества
   */
  calculateSeverity(e) {
    return e >= 50 ? "critical" : e >= 20 ? "high" : e >= 10 ? "medium" : "low";
  }
  /**
   * Извлечение тегов из сообщения об ошибке
   */
  extractErrorTags(e) {
    const t = [], r = e.toLowerCase();
    return (r.includes("network") || r.includes("fetch")) && t.push("network"), r.includes("timeout") && t.push("timeout"), (r.includes("memory") || r.includes("out of memory")) && t.push("memory"), (r.includes("api") || r.includes("http")) && t.push("api"), (r.includes("auth") || r.includes("authentication")) && t.push("authentication"), r.includes("pyodide") && t.push("pyodide"), r.includes("workflow") && t.push("workflow"), t.length > 0 ? t : ["general"];
  }
}, I = class {
  constructor(e, t, r) {
    i(this, "config");
    i(this, "logger");
    i(this, "metricsCollector");
    i(this, "measurements", /* @__PURE__ */ new Map());
    i(this, "completedMeasurements", []);
    this.config = e, this.logger = t, this.metricsCollector = r;
  }
  /**
   * Начало измерения производительности
   */
  startOperation(e, t = {}, r = "unknown") {
    const s = this.generateTraceId(), o = {
      operationName: e,
      startTime: performance.now(),
      success: !1,
      labels: t,
      traceId: s,
      component: r
    };
    return this.measurements.set(s, o), this.logger.debug(r, `Started operation: ${e}`, {
      traceId: s,
      labels: t,
      ...this.sanitizeLabels(t)
    }), s;
  }
  /**
   * Завершение измерения производительности
   */
  endOperation(e, t = !0, r, s) {
    const o = this.measurements.get(e);
    return o ? (o.endTime = performance.now(), o.duration = o.endTime - o.startTime, o.success = t, o.error = r, s && (o.labels = { ...o.labels, ...s }), this.measurements.delete(e), this.completedMeasurements.push(o), this.completedMeasurements.length > 1e3 && (this.completedMeasurements = this.completedMeasurements.slice(-1e3)), t ? (this.metricsCollector.recordHistogram(
      "operation_duration_seconds",
      o.duration / 1e3,
      {
        operation: o.operationName,
        component: o.component,
        success: "true",
        ...this.sanitizeLabels(o.labels)
      }
    ), this.metricsCollector.incrementCounter("operations_completed_total", {
      operation: o.operationName,
      component: o.component,
      ...this.sanitizeLabels(o.labels)
    })) : (this.metricsCollector.recordHistogram(
      "failed_operation_duration_seconds",
      o.duration / 1e3,
      {
        operation: o.operationName,
        component: o.component,
        success: "false",
        ...this.sanitizeLabels(o.labels)
      }
    ), this.metricsCollector.incrementCounter("operations_failed_total", {
      operation: o.operationName,
      component: o.component,
      ...this.sanitizeLabels(o.labels)
    })), this.logger.debug(o.component, `Completed operation: ${o.operationName}`, {
      traceId: e,
      duration: o.duration,
      success: t,
      ...this.sanitizeLabels(o.labels)
    }), o.duration) : (this.logger.warn("PerformanceMonitor", `Measurement not found for traceId: ${e}`), null);
  }
  /**
   * Удобный метод для измерения операции через колбэк
   */
  recordOperation(e, t, r = {}) {
    const s = this.startOperation(e, r);
    return t().then((o) => (this.endOperation(s, !0), o)).catch((o) => {
      throw this.endOperation(s, !1, o), o;
    });
  }
  /**
   * Получение статистики производительности
   */
  getPerformanceStats() {
    const e = {}, t = {};
    this.completedMeasurements.forEach((o) => {
      const n = o.component, a = o.operationName;
      e[n] || (e[n] = { durations: [], successCount: 0, totalCount: 0 }), t[a] || (t[a] = { durations: [], successCount: 0, totalCount: 0 }), o.duration && (e[n].durations.push(o.duration), t[a].durations.push(o.duration)), e[n].totalCount++, t[a].totalCount++, o.success && (e[n].successCount++, t[a].successCount++);
    });
    const r = Object.entries(t).map(([o, n]) => ({
      operation: o,
      avgDuration: n.durations.reduce((a, l) => a + l, 0) / n.durations.length,
      maxDuration: Math.max(...n.durations),
      count: n.totalCount,
      successRate: n.successCount / n.totalCount * 100
    })).sort((o, n) => n.avgDuration - o.avgDuration).slice(0, 10), s = {};
    return Object.entries(e).forEach(([o, n]) => {
      s[o] = {
        avgDuration: n.durations.reduce((a, l) => a + l, 0) / n.durations.length,
        operationCount: n.totalCount,
        successRate: n.successCount / n.totalCount * 100
      };
    }), {
      activeOperations: this.measurements.size,
      slowestOperations: r,
      componentStats: s
    };
  }
  /**
   * Очистка завершенных измерений старше определенного времени
   */
  cleanupCompletedMeasurements(e = 3600 * 1e3) {
    const t = Date.now() - e, r = this.completedMeasurements.length;
    this.completedMeasurements = this.completedMeasurements.filter(
      (o) => o.endTime && o.endTime > t
    );
    const s = r - this.completedMeasurements.length;
    return s > 0 && this.logger.debug("PerformanceMonitor", `Cleaned up ${s} old performance measurements`), s;
  }
  /**
   * Получение активных операций (которые не завершились)
   */
  getActiveOperations() {
    return Array.from(this.measurements.values());
  }
  /**
   * Аварийное завершение операци (например, при таймауте)
   */
  cancelOperation(e, t = "cancelled") {
    const r = this.measurements.get(e);
    return r ? (r.endTime = performance.now(), r.duration = r.endTime - r.startTime, r.success = !1, r.error = new Error(t), r.labels.cancelled = "true", this.endOperation(e, !1, r.error, { cancelled_reason: t }), !0) : !1;
  }
  // ===== PRIVATE METHODS =====
  /**
   * Генерация уникального ID трассировки
   */
  generateTraceId() {
    return `perf_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  /**
   * Очистка меток для безопасного логирования
   */
  sanitizeLabels(e) {
    const t = {};
    return Object.entries(e).forEach(([r, s]) => {
      typeof s == "string" && s.length > 1e3 ? t[r] = s.substring(0, 1e3) + "..." : t[r] = String(s);
    }), t;
  }
}, D = class {
  constructor(e, t, r) {
    i(this, "config");
    i(this, "logger");
    i(this, "metricsCollector");
    i(this, "activeRequests", /* @__PURE__ */ new Map());
    i(this, "completedRequests", []);
    i(this, "requestMacros", /* @__PURE__ */ new Map());
    // domain -> urls for pattern matching
    i(this, "logPrefix", "[NetworkTracker]");
    i(this, "maxCompletedRequests", 500);
    this.config = e, this.logger = t, this.metricsCollector = r, this.initializeInterceptors();
  }
  /**
   * Отслеживание сетевого запроса
   */
  trackRequest(e, t) {
    const r = t || this.generateRequestId(), s = {
      ...e,
      requestId: r,
      startTime: performance.now(),
      component: e.component || "unknown"
    };
    return this.activeRequests.set(r, s), this.shouldSample("networkRequests") && this.logger.debug(s.component, `Network request started: ${s.method} ${this.sanitizeUrl(s.url)}`, {
      requestId: r,
      method: s.method,
      url: s.url,
      labels: s.labels
    }), this.metricsCollector.incrementCounter("network_requests_total", {
      method: s.method,
      component: s.component,
      domain: this.extractDomain(s.url)
    }), r;
  }
  /**
   * Завершение отслеживания запроса
   */
  completeRequest(e, t, r, s, o) {
    const n = this.activeRequests.get(e);
    if (!n) {
      this.logger.warn("NetworkTracker", `Request not found: ${e}`);
      return;
    }
    n.endTime = performance.now(), n.duration = n.endTime - n.startTime, n.success = t, n.statusCode = r, n.responseSize = s, n.error = o, this.activeRequests.delete(e), this.completedRequests.push(n), this.completedRequests.length > this.maxCompletedRequests && (this.completedRequests = this.completedRequests.slice(-this.maxCompletedRequests)), this.recordMetrics(n), this.shouldSample("networkRequests") && this.logger.debug(n.component, `Network request completed: ${n.method} ${this.sanitizeUrl(n.url)}`, {
      requestId: e,
      success: t,
      statusCode: r,
      duration: n.duration,
      error: o == null ? void 0 : o.message
    }), this.checkRequestAlerts(n);
  }
  /**
   * Удобный метод через Promise
   */
  async trackFetch(e, t, r = "unknown") {
    const s = t.method || "GET", o = this.trackRequest({
      url: e,
      method: s,
      component: r,
      success: !1,
      labels: { ...t.headers, ...t }
    });
    try {
      const n = performance.now(), a = await fetch(e, t), l = performance.now() - n, m = Number(a.headers.get("content-length")) || 0, d = a.ok;
      return this.completeRequest(
        o,
        d,
        a.status,
        m
      ), a;
    } catch (n) {
      throw this.completeRequest(o, !1, void 0, void 0, n), n;
    }
  }
  /**
   * Получение статистики сетевых запросов
   */
  getNetworkStats(e) {
    let t = this.completedRequests;
    if (e && (t = t.filter(
      (c) => c.startTime >= e.from && c.startTime <= e.to
    )), t.length === 0)
      return {
        totalRequests: 0,
        successRate: 100,
        averageResponseTime: 0,
        requestsByStatus: {},
        slowestRequests: [],
        requestsByDomain: {},
        errorPatterns: {}
      };
    const r = t.length, o = t.filter((c) => c.success).length / r * 100, n = t.filter((c) => c.duration).reduce((c, h) => c + (h.duration || 0), 0) / t.length, a = {}, l = {}, m = {};
    t.forEach((c) => {
      c.statusCode && (a[c.statusCode] = (a[c.statusCode] || 0) + 1);
      const h = this.extractDomain(c.url);
      if (l[h] = (l[h] || 0) + 1, !c.success && c.error) {
        const f = this.extractErrorPattern(c.error);
        m[f] = (m[f] || 0) + 1;
      }
    });
    const d = t.filter((c) => c.duration).sort((c, h) => (h.duration || 0) - (c.duration || 0)).slice(0, 10).map((c) => ({
      url: this.sanitizeUrl(c.url),
      method: c.method,
      duration: c.duration || 0,
      statusCode: c.statusCode || 0
    }));
    return {
      totalRequests: r,
      successRate: o,
      averageResponseTime: n,
      requestsByStatus: a,
      slowestRequests: d,
      requestsByDomain: l,
      errorPatterns: m
    };
  }
  /**
   * Получение активных сетевых запросов
   */
  getActiveRequests() {
    return Array.from(this.activeRequests.values());
  }
  /**
   * Очистка завершенных запросов старше определенного времени
   */
  cleanupCompletedRequests(e = 1800 * 1e3) {
    const t = Date.now() - e, r = this.completedRequests.length;
    this.completedRequests = this.completedRequests.filter(
      (o) => o.startTime > t
    );
    const s = r - this.completedRequests.length;
    return s > 0 && this.logger.debug("NetworkTracker", `Cleaned up ${s} old network requests`), s;
  }
  // ===== PRIVATE METHODS =====
  /**
   * Инициализация перехватчиков для автоматического отслеживания
   */
  initializeInterceptors() {
    if (typeof window < "u" && window.fetch) {
      const e = window.fetch;
      window.fetch = this.createMonitoredFetch(e);
    }
    if (typeof XMLHttpRequest < "u") {
      const e = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = this.createMonitoredXmlHttpRequest(e);
    }
  }
  /**
   * Создание monitored версии fetch
   */
  createMonitoredFetch(e) {
    return async (t, r) => {
      const s = typeof t == "string" ? t : t.url, o = (r == null ? void 0 : r.method) || "GET", n = this.trackRequest({
        url: s,
        method: o,
        component: "fetch_api",
        success: !1,
        labels: { component: "fetch_api" }
      });
      try {
        const a = performance.now(), l = await e(t, r), m = performance.now() - a, d = l.ok, c = l.status, h = Number(l.headers.get("content-length")) || 0;
        return this.completeRequest(n, d, c, h), l;
      } catch (a) {
        throw this.completeRequest(n, !1, void 0, void 0, a), a;
      }
    };
  }
  /**
   * Создание monitored версии XMLHttpRequest
   */
  createMonitoredXmlHttpRequest(e) {
    return function(t, r, s, o, n) {
      const a = R().getNetworkTracker(), l = a.trackRequest({
        url: typeof r == "string" ? r : r.toString(),
        method: t.toUpperCase(),
        component: "xhr_api",
        success: !1,
        labels: { component: "xhr_api" }
      }), m = this.onreadystatechange;
      return this.onreadystatechange = (d) => {
        var c, h;
        this.readyState === XMLHttpRequest.DONE && a.completeRequest(
          l,
          this.status >= 200 && this.status < 300,
          this.status,
          ((c = this.response) == null ? void 0 : c.length) || ((h = this.responseText) == null ? void 0 : h.length) || 0
        ), m && m.call(this, d);
      }, e.call(this, t, r, s, o, n);
    };
  }
  /**
   * Регистрация метрик для запроса
   */
  recordMetrics(e) {
    var t;
    this.metricsCollector.incrementCounter("network_requests_total", {
      method: e.method,
      component: e.component,
      status: ((t = e.statusCode) == null ? void 0 : t.toString()) || "unknown"
    }), e.duration && this.metricsCollector.recordHistogram("network_request_duration_seconds", e.duration / 1e3, {
      method: e.method,
      component: e.component,
      success: e.success.toString()
    }), e.statusCode && (this.metricsCollector.incrementCounter("network_status_codes_total", {
      status_code: e.statusCode.toString(),
      method: e.method,
      component: e.component
    }), e.statusCode >= 400 && this.metricsCollector.incrementCounter("network_errors_total", {
      status_code: e.statusCode.toString(),
      method: e.method,
      component: e.component,
      url: this.sanitizeUrl(e.url)
    })), e.responseSize && this.metricsCollector.recordHistogram("network_response_size_bytes", e.responseSize, {
      method: e.method,
      component: e.component
    });
  }
  /**
   * Проверка алертов для медленных или неудачных запросов
   */
  checkRequestAlerts(e) {
    e.duration && (e.duration > 3e4 && this.logger.warn("NetworkTracker", "Very slow network request", {
      url: this.sanitizeUrl(e.url),
      method: e.method,
      duration: e.duration,
      component: e.component
    }), !e.success && e.statusCode && e.statusCode >= 500 && this.logger.error("NetworkTracker", "Server error in network request", {
      url: this.sanitizeUrl(e.url),
      method: e.method,
      statusCode: e.statusCode,
      component: e.component
    }));
  }
  /**
   * Генерация уникального ID запроса
   */
  generateRequestId() {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  /**
   * Извлечение домена из URL
   */
  extractDomain(e) {
    try {
      return new URL(e).hostname;
    } catch {
      return "unknown";
    }
  }
  /**
   * Очистка чувствительной информации из URL
   */
  sanitizeUrl(e) {
    try {
      const t = new URL(e);
      return t.searchParams.delete("key"), t.searchParams.delete("token"), t.searchParams.delete("api_key"), t.searchParams.delete("password"), t.href;
    } catch {
      return "invalid-url";
    }
  }
  /**
   * Извлечение паттерна ошибки
   */
  extractErrorPattern(e) {
    const t = e.message.toLowerCase();
    return t.includes("timeout") ? "timeout" : t.includes("network") ? "network_error" : t.includes("cors") ? "cors_error" : t.includes("aborted") ? "aborted" : "other_error";
  }
  /**
   * Проверка, следует ли сэмплировать запрос
   */
  shouldSample(e) {
    return this.config.samplingRates[e] >= 1 ? !0 : Math.random() < this.config.samplingRates[e];
  }
};
function R() {
  return globalThis.__MONITORING_CORE__;
}
function z(u = {}) {
  const e = {
    enableConsoleLogging: !0,
    enableErrorCapture: u.enableErrorCapture ?? !0,
    enablePerformanceMetrics: u.enablePerformanceTracking ?? !0,
    enableMemoryTracking: !0,
    enableNetworkRequestTracking: u.enableNetworkTracking ?? !0,
    samplingRates: {
      errorEvents: 1,
      performanceMetrics: u.sampleRate ?? 0.1,
      networkRequests: u.sampleRate ?? 0.5
    },
    alertThresholds: {
      maxPyodideMemory: 256,
      maxWorkflowDuration: 300,
      maxApiCallDuration: 60,
      maxErrorRate: 10,
      maxConsecutiveFailures: 5,
      ...u.alertThresholds
    }
  }, t = getMonitoringCore(e);
  return globalThis.__MONITORING_CORE__ = t, t;
}
export {
  S as AlertManager,
  $ as ErrorTracker,
  _ as MetricsCollector,
  C as MonitoringCore,
  A as MonitoringLogger,
  D as NetworkTracker,
  I as PerformanceMonitor,
  z as default,
  M as getMonitoringCore,
  z as initializeMonitoring
};
