function we(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var he = { exports: {} }, k = he.exports = {}, F, x;
function te() {
  throw new Error("setTimeout has not been defined");
}
function ne() {
  throw new Error("clearTimeout has not been defined");
}
(function() {
  try {
    typeof setTimeout == "function" ? F = setTimeout : F = te;
  } catch {
    F = te;
  }
  try {
    typeof clearTimeout == "function" ? x = clearTimeout : x = ne;
  } catch {
    x = ne;
  }
})();
function Ae(e) {
  if (F === setTimeout)
    return setTimeout(e, 0);
  if ((F === te || !F) && setTimeout)
    return F = setTimeout, setTimeout(e, 0);
  try {
    return F(e, 0);
  } catch {
    try {
      return F.call(null, e, 0);
    } catch {
      return F.call(this, e, 0);
    }
  }
}
function Se(e) {
  if (x === clearTimeout)
    return clearTimeout(e);
  if ((x === ne || !x) && clearTimeout)
    return x = clearTimeout, clearTimeout(e);
  try {
    return x(e);
  } catch {
    try {
      return x.call(null, e);
    } catch {
      return x.call(this, e);
    }
  }
}
var G = [], W = !1, $, J = -1;
function Ne() {
  !W || !$ || (W = !1, $.length ? G = $.concat(G) : J = -1, G.length && Te());
}
function Te() {
  if (!W) {
    var e = Ae(Ne);
    W = !0;
    for (var n = G.length; n; ) {
      for ($ = G, G = []; ++J < n; )
        $ && $[J].run();
      J = -1, n = G.length;
    }
    $ = null, W = !1, Se(e);
  }
}
k.nextTick = function(e) {
  var n = new Array(arguments.length - 1);
  if (arguments.length > 1)
    for (var t = 1; t < arguments.length; t++)
      n[t - 1] = arguments[t];
  G.push(new be(e, n)), G.length === 1 && !W && Ae(Te);
};
function be(e, n) {
  this.fun = e, this.array = n;
}
be.prototype.run = function() {
  this.fun.apply(null, this.array);
};
k.title = "browser";
k.browser = !0;
k.env = {};
k.argv = [];
k.version = "";
k.versions = {};
function M() {
}
k.on = M;
k.addListener = M;
k.once = M;
k.off = M;
k.removeListener = M;
k.removeAllListeners = M;
k.emit = M;
k.prependListener = M;
k.prependOnceListener = M;
k.listeners = function(e) {
  return [];
};
k.binding = function(e) {
  throw new Error("process.binding is not supported");
};
k.cwd = function() {
  return "/";
};
k.chdir = function(e) {
  throw new Error("process.chdir is not supported");
};
k.umask = function() {
  return 0;
};
var De = he.exports;
const _e = /* @__PURE__ */ we(De);
var Z = { exports: {} }, Le = Z.exports, ce;
function Pe() {
  return ce || (ce = 1, (function(e, n) {
    (function(t, s) {
      s(e);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : Le, function(t) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        t.exports = globalThis.browser;
      else {
        const s = "The message port closed before a response was received.", r = (o) => {
          const a = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(a).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class c extends WeakMap {
            constructor(d, h = void 0) {
              super(h), this.createItem = d;
            }
            get(d) {
              return this.has(d) || this.set(d, this.createItem(d)), super.get(d);
            }
          }
          const i = (g) => g && typeof g == "object" && typeof g.then == "function", E = (g, d) => (...h) => {
            o.runtime.lastError ? g.reject(new Error(o.runtime.lastError.message)) : d.singleCallbackArg || h.length <= 1 && d.singleCallbackArg !== !1 ? g.resolve(h[0]) : g.resolve(h);
          }, m = (g) => g == 1 ? "argument" : "arguments", l = (g, d) => function(A, ...I) {
            if (I.length < d.minArgs)
              throw new Error(`Expected at least ${d.minArgs} ${m(d.minArgs)} for ${g}(), got ${I.length}`);
            if (I.length > d.maxArgs)
              throw new Error(`Expected at most ${d.maxArgs} ${m(d.maxArgs)} for ${g}(), got ${I.length}`);
            return new Promise((D, _) => {
              if (d.fallbackToNoCallback)
                try {
                  A[g](...I, E({
                    resolve: D,
                    reject: _
                  }, d));
                } catch (p) {
                  console.warn(`${g} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, p), A[g](...I), d.fallbackToNoCallback = !1, d.noCallback = !0, D();
                }
              else d.noCallback ? (A[g](...I), D()) : A[g](...I, E({
                resolve: D,
                reject: _
              }, d));
            });
          }, u = (g, d, h) => new Proxy(d, {
            apply(A, I, D) {
              return h.call(I, g, ...D);
            }
          });
          let f = Function.call.bind(Object.prototype.hasOwnProperty);
          const O = (g, d = {}, h = {}) => {
            let A = /* @__PURE__ */ Object.create(null), I = {
              has(_, p) {
                return p in g || p in A;
              },
              get(_, p, L) {
                if (p in A)
                  return A[p];
                if (!(p in g))
                  return;
                let C = g[p];
                if (typeof C == "function")
                  if (typeof d[p] == "function")
                    C = u(g, g[p], d[p]);
                  else if (f(h, p)) {
                    let Y = l(p, h[p]);
                    C = u(g, g[p], Y);
                  } else
                    C = C.bind(g);
                else if (typeof C == "object" && C !== null && (f(d, p) || f(h, p)))
                  C = O(C, d[p], h[p]);
                else if (f(h, "*"))
                  C = O(C, d[p], h["*"]);
                else
                  return Object.defineProperty(A, p, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return g[p];
                    },
                    set(Y) {
                      g[p] = Y;
                    }
                  }), C;
                return A[p] = C, C;
              },
              set(_, p, L, C) {
                return p in A ? A[p] = L : g[p] = L, !0;
              },
              defineProperty(_, p, L) {
                return Reflect.defineProperty(A, p, L);
              },
              deleteProperty(_, p) {
                return Reflect.deleteProperty(A, p);
              }
            }, D = Object.create(g);
            return new Proxy(D, I);
          }, P = (g) => ({
            addListener(d, h, ...A) {
              d.addListener(g.get(h), ...A);
            },
            hasListener(d, h) {
              return d.hasListener(g.get(h));
            },
            removeListener(d, h) {
              d.removeListener(g.get(h));
            }
          }), U = new c((g) => typeof g != "function" ? g : function(h) {
            const A = O(h, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            g(A);
          }), z = new c((g) => typeof g != "function" ? g : function(h, A, I) {
            let D = !1, _, p = new Promise((V) => {
              _ = function(R) {
                D = !0, V(R);
              };
            }), L;
            try {
              L = g(h, A, _);
            } catch (V) {
              L = Promise.reject(V);
            }
            const C = L !== !0 && i(L);
            if (L !== !0 && !C && !D)
              return !1;
            const Y = (V) => {
              V.then((R) => {
                I(R);
              }, (R) => {
                let oe;
                R && (R instanceof Error || typeof R.message == "string") ? oe = R.message : oe = "An unexpected error occurred", I({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: oe
                });
              }).catch((R) => {
                console.error("Failed to send onMessage rejected reply", R);
              });
            };
            return Y(C ? L : p), !0;
          }), T = ({
            reject: g,
            resolve: d
          }, h) => {
            o.runtime.lastError ? o.runtime.lastError.message === s ? d() : g(new Error(o.runtime.lastError.message)) : h && h.__mozWebExtensionPolyfillReject__ ? g(new Error(h.message)) : d(h);
          }, H = (g, d, h, ...A) => {
            if (A.length < d.minArgs)
              throw new Error(`Expected at least ${d.minArgs} ${m(d.minArgs)} for ${g}(), got ${A.length}`);
            if (A.length > d.maxArgs)
              throw new Error(`Expected at most ${d.maxArgs} ${m(d.maxArgs)} for ${g}(), got ${A.length}`);
            return new Promise((I, D) => {
              const _ = T.bind(null, {
                resolve: I,
                reject: D
              });
              A.push(_), h.sendMessage(...A);
            });
          }, Oe = {
            devtools: {
              network: {
                onRequestFinished: P(U)
              }
            },
            runtime: {
              onMessage: P(z),
              onMessageExternal: P(z),
              sendMessage: H.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: H.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, re = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return a.privacy = {
            network: {
              "*": re
            },
            services: {
              "*": re
            },
            websites: {
              "*": re
            }
          }, O(o, Oe, a);
        };
        t.exports = r(chrome);
      }
    });
  })(Z)), Z.exports;
}
Pe();
const b = function(e) {
  if (!e) return "unknown-page";
  try {
    const n = new URL(e);
    return n.search = "", n.hash = "", n.toString();
  } catch {
    return e;
  }
}, w = {
  // Создание чата при начале ввода (ленивая инициализация)
  async createChatIfNotExists(e, n) {
    var a;
    const t = `${e}::${b(n)}`;
    console.log("[pluginChatApi] createChatIfNotExists: начало", {
      pluginId: e,
      pageKey: n,
      chatKey: t,
      normalizedPageKey: b(n)
    });
    const s = await this.getOrLoadChat(t);
    if (s)
      return console.log("[pluginChatApi] createChatIfNotExists: чат уже существует", {
        chat: s,
        messagesLength: (a = s.messages) == null ? void 0 : a.length
      }), s;
    const r = Date.now(), o = {
      chatKey: t,
      pluginId: e,
      pageKey: n,
      messages: [],
      createdAt: r,
      updatedAt: r
    };
    return console.log("[pluginChatApi] createChatIfNotExists: создаём новый чат", {
      newChat: o,
      chatKey: t,
      serializedSize: JSON.stringify(o).length
    }), await new Promise((c, i) => {
      chrome.storage.local.set({ [t]: o }, () => {
        if (chrome.runtime.lastError) {
          console.error("[pluginChatApi] createChatIfNotExists: ошибка создания чата", chrome.runtime.lastError), i(chrome.runtime.lastError);
          return;
        }
        console.log("[pluginChatApi] createChatIfNotExists: создан новый чат", o), chrome.storage.local.get([t], (E) => {
          var l;
          const m = E[t];
          console.log("[pluginChatApi] createChatIfNotExists: проверка после создания", {
            savedChat: m,
            savedChatType: typeof m,
            savedMessagesLength: (l = m == null ? void 0 : m.messages) == null ? void 0 : l.length
          }), c();
        });
      });
    }), o;
  },
  // Получить чат по ключу или null
  async getOrLoadChat(e) {
    return new Promise((n) => {
      chrome.storage.local.get([e], (t) => {
        var r;
        const s = t[e] || null;
        console.log("[pluginChatApi] getOrLoadChat:", {
          chatKey: e,
          chat: s,
          chatType: typeof s,
          hasChat: !!s,
          messages: s == null ? void 0 : s.messages,
          messagesType: typeof (s == null ? void 0 : s.messages),
          messagesLength: (r = s == null ? void 0 : s.messages) == null ? void 0 : r.length,
          storageKeys: Object.keys(t)
        }), chrome.storage.local.get(null, (o) => {
          const a = Object.keys(o).filter((c) => c.includes(e.split("::")[0]));
          console.log("[pluginChatApi] getOrLoadChat - all storage keys:", Object.keys(o)), console.log("[pluginChatApi] getOrLoadChat - related keys:", a), console.log("[pluginChatApi] getOrLoadChat - all data:", o);
        }), n(s);
      });
    });
  },
  // Сохранить сообщение в чат
  async saveMessage(e, n, t) {
    var o;
    const s = `${e}::${b(n)}`;
    console.log("[pluginChatApi][saveMessage] BEFORE", {
      chatKey: s,
      pluginId: e,
      pageKey: n,
      message: t,
      messageType: typeof t,
      messageKeys: Object.keys(t),
      pageKeyNormalized: b(n)
    });
    let r = await this.getOrLoadChat(s);
    if (!r && (console.warn("[pluginChatApi][saveMessage] чат не найден, создаём новый"), await this.createChatIfNotExists(e, n), r = await this.getOrLoadChat(s), !r))
      return console.error("[pluginChatApi][saveMessage] не удалось создать чат!"), { success: !1 };
    console.log("[pluginChatApi][saveMessage] перед push:", {
      chatMessagesLength: (o = r.messages) == null ? void 0 : o.length,
      messageToAdd: t
    }), r.messages.push(t), console.log("[pluginChatApi][saveMessage] chat.messages после push:", {
      messages: r.messages,
      messagesLength: r.messages.length,
      lastMessage: r.messages[r.messages.length - 1]
    }), r.updatedAt = Date.now();
    try {
      const a = JSON.stringify(r);
      console.log("[pluginChatApi][saveMessage] сериализация успешна:", {
        originalSize: JSON.stringify(r).length,
        messagesCount: r.messages.length
      });
    } catch (a) {
      return console.error("[pluginChatApi][saveMessage] ошибка сериализации:", a), { success: !1 };
    }
    return await new Promise((a) => {
      chrome.storage.local.set({ [s]: r }, () => {
        if (chrome.runtime.lastError) {
          console.error("[pluginChatApi][saveMessage] chrome.storage error:", chrome.runtime.lastError), a();
          return;
        }
        console.log("[pluginChatApi][saveMessage] AFTER set:", {
          chatKey: s,
          chat: r,
          success: !0
        }), chrome.storage.local.get([s], (c) => {
          var E, m;
          const i = c[s];
          console.log("[pluginChatApi][saveMessage] ПРОВЕРКА storage после set:", {
            savedChat: i,
            savedChatType: typeof i,
            savedMessagesLength: (E = i == null ? void 0 : i.messages) == null ? void 0 : E.length,
            savedMessages: i == null ? void 0 : i.messages,
            lastSavedMessage: (m = i == null ? void 0 : i.messages) == null ? void 0 : m[i.messages.length - 1]
          });
        }), a();
      });
    }), { success: !0 };
  },
  // Удалить чат
  async deleteChat(e, n) {
    const t = `${e}::${b(n)}`;
    return await new Promise((s) => {
      chrome.storage.local.remove([t], () => {
        console.log("[pluginChatApi] deleteChat:", t), s();
      });
    }), { success: !0 };
  },
  // Сохранить черновик
  async saveDraft(e, n, t) {
    const s = `${e}::${b(n)}::draft`, r = {
      draftKey: s,
      pluginId: e,
      pageKey: n,
      text: t,
      updatedAt: Date.now()
    };
    return console.log("[pluginChatApi][saveDraft] BEFORE", { draftKey: s, pluginId: e, pageKey: n, text: t }), await new Promise((o) => {
      chrome.storage.local.set({ [s]: r }, () => {
        console.log("[pluginChatApi][saveDraft] AFTER", { draftKey: s, pluginId: e, pageKey: n, text: t, draft: r }), o();
      });
    }), { success: !0 };
  },
  // Получить черновик
  async getDraft(e, n) {
    const t = `${e}::${b(n)}::draft`;
    return console.log("[pluginChatApi][getDraft] BEFORE", { draftKey: t, pluginId: e, pageKey: n }), new Promise((s) => {
      chrome.storage.local.get([t], (r) => {
        const o = r[t], a = o && typeof o.text == "string" ? o.text : "";
        console.log("[pluginChatApi][getDraft] AFTER", { draftKey: t, pluginId: e, pageKey: n, draft: o, draftText: a }), s({ draftText: a });
      });
    });
  },
  // Удалить черновик
  async deleteDraft(e, n) {
    const t = `${e}::${b(n)}::draft`;
    return console.log("[pluginChatApi][deleteDraft] BEFORE", { draftKey: t, pluginId: e, pageKey: n }), await new Promise((s) => {
      chrome.storage.local.remove([t], () => {
        console.log("[pluginChatApi][deleteDraft] AFTER", { draftKey: t, pluginId: e, pageKey: n }), s();
      });
    }), { success: !0 };
  },
  // Получить список всех черновиков для плагина
  async listDraftsForPlugin(e) {
    return new Promise((n) => {
      chrome.storage.local.get(null, (t) => {
        const s = Object.values(t).filter(
          (r) => !!(r && typeof r == "object" && "draftKey" in r && "pluginId" in r && r.pluginId === e)
        );
        console.log("[pluginChatApi] listDraftsForPlugin:", e, s), n(s);
      });
    });
  },
  // Получить список всех чатов для плагина
  async listChatsForPlugin(e) {
    return new Promise((n) => {
      chrome.storage.local.get(null, (t) => {
        const s = Object.values(t).filter(
          (r) => !!(r && typeof r == "object" && "chatKey" in r && "pluginId" in r && r.pluginId === e)
        );
        console.log("[pluginChatApi] listChatsForPlugin:", e, s), n(s);
      });
    });
  }
}, ie = ["ozon-analyzer", "google-helper", "test-plugin", "time-test"];
async function ae() {
  const e = [];
  console.log("[plugin-manager] Starting getAvailablePlugins with dirs:", ie);
  for (const n of ie)
    try {
      console.log(`[plugin-manager] Processing plugin: ${n}`);
      const t = chrome.runtime.getURL(`plugins/${n}/manifest.json`);
      console.log(`[plugin-manager] Manifest URL for ${n}:`, t);
      const s = await fetch(t);
      if (console.log(`[plugin-manager] Fetch response for ${n}:`, s.status, s.statusText), !s.ok)
        throw new Error(`Failed to fetch manifest: ${s.statusText}`);
      const r = await s.json();
      console.log(`[plugin-manager] Parsed manifest for ${n}:`, r);
      const o = {
        id: n,
        name: r.name,
        version: r.version,
        description: r.description,
        icon: r.icon,
        iconUrl: chrome.runtime.getURL(`plugins/${n}/${r.icon || "icon.svg"}`),
        manifest: r
      };
      console.log(`[plugin-manager] Created plugin object for ${n}:`, o), e.push(o);
    } catch (t) {
      console.error(`[plugin-manager] Failed to load plugin from '${n}':`, t), console.error(`[plugin-manager] Error details for ${n}:`, {
        message: t.message,
        stack: t.stack
      });
    }
  return console.log("[plugin-manager] Final plugins array:", e), console.log("[plugin-manager] Returning", e.length, "plugins"), e;
}
var Re = { CLI_CEB_DEV: "false", CLI_CEB_FIREFOX: "false", CEB_EXAMPLE: "example_env", CEB_DEV_LOCALE: "", CEB_CI: "", CEB_NODE_ENV: "production" };
let N = null;
const y = {
  totalRequests: 0,
  successRequests: 0,
  failedRequests: 0,
  rateLimitedRequests: 0,
  fallbackRequests: 0,
  providerStats: /* @__PURE__ */ new Map(),
  modelUsage: /* @__PURE__ */ new Map()
};
function Fe() {
  if (!N)
    try {
      import("./index-CONGKhJs.js").then((e) => {
        N = e.initializeMonitoring({
          sampleRate: 0.9,
          // высокая сэмплировка для AI API
          enableErrorCapture: !0
        }), N && console.log("[AI Client] Monitoring system initialized");
      }).catch((e) => {
        console.warn("[AI Client] Cannot load monitoring system:", (e == null ? void 0 : e.message) || String(e));
      });
    } catch (e) {
      console.warn("[AI Client] Cannot initialize monitoring:", (e == null ? void 0 : e.message) || String(e));
    }
}
function le(e) {
  y.totalRequests++;
  const n = y.providerStats.get(e.provider) || {
    requests: 0,
    failures: 0,
    avgResponseTime: 0,
    totalTokens: 0
  };
  n.requests++, e.success || n.failures++, e.responseTime && (n.avgResponseTime = (n.avgResponseTime + e.responseTime) / 2), e.tokensUsed && (n.totalTokens += e.tokensUsed), y.providerStats.set(e.provider, n);
  const t = y.modelUsage.get(e.model) || {
    requests: 0,
    tokensUsed: 0,
    lastUsed: 0
  };
  t.requests++, e.tokensUsed && (t.tokensUsed += e.tokensUsed), t.lastUsed = Date.now(), y.modelUsage.set(e.model, t), e.success ? y.successRequests++ : y.failedRequests++, e.rateLimited && y.rateLimitedRequests++, e.fallbackAttempted && y.fallbackRequests++, N && (N.getMetricsCollector().incrementCounter("ai_api_calls_total", {
    model: e.model,
    provider: e.provider,
    success: e.success ? "true" : "false",
    rate_limited: e.rateLimited ? "true" : "false",
    fallback_attempted: e.fallbackAttempted ? "true" : "false"
  }), e.responseTime && N.getMetricsCollector().recordHistogram(
    "ai_api_response_time_seconds",
    e.responseTime / 1e3,
    {
      model: e.model,
      provider: e.provider
    }
  ), e.tokensUsed && N.getMetricsCollector().incrementCounter("ai_tokens_used_total", {
    model: e.model,
    provider: e.provider
  }, e.tokensUsed), xe(e));
}
function xe(e) {
  if (!N) return;
  const n = y.failedRequests / y.totalRequests;
  n > 0.3 && y.failedRequests > 5 && N.captureError("ai_api_high_failure_rate", new Error(`AI API failure rate: ${(n * 100).toFixed(1)}%`), {
    component: "ai_client",
    totalRequests: y.totalRequests,
    failedRequests: y.failedRequests,
    lastModel: e.model
  }), e.rateLimited && N.getLogger().warn("ai_client", "AI API rate limit exceeded", {
    model: e.model,
    provider: e.provider
  });
  const t = y.fallbackRequests / y.totalRequests;
  t > 0.5 && y.fallbackRequests > 3 && N.getLogger().warn("ai_client", "High fallback usage detected", {
    fallbackRate: `${(t * 100).toFixed(1)}%`,
    totalFallbacks: y.fallbackRequests
  });
}
const Q = {
  "gemini-flash": {
    provider: "google",
    model_name: "gemini-1.5-flash-latest",
    endpoint: "https://generativelanguage.googleapis.com/v1beta/models/",
    api_key_env: "GOOGLE_AI_API_KEY"
  },
  "gemini-pro": {
    provider: "google",
    model_name: "gemini-1.5-pro-latest",
    endpoint: "https://generativelanguage.googleapis.com/v1beta/models/",
    api_key_env: "GOOGLE_AI_API_KEY"
  },
  "gemini-25": {
    provider: "google",
    model_name: "gemini-1.5-flash-8b-latest",
    endpoint: "https://generativelanguage.googleapis.com/v1beta/models/",
    api_key_env: "GOOGLE_AI_API_KEY"
  },
  "gpt-3.5-turbo": {
    provider: "openai",
    model_name: "gpt-3.5-turbo",
    endpoint: "https://api.openai.com/v1/chat/completions",
    api_key_env: "OPENAI_API_KEY"
  },
  "gpt-4": {
    provider: "openai",
    model_name: "gpt-4",
    endpoint: "https://api.openai.com/v1/chat/completions",
    api_key_env: "OPENAI_API_KEY"
  }
};
async function Ge(e) {
  try {
    if (!Object.keys(Q).includes(e))
      throw new Error(`Неизвестная модель: ${e}`);
    const n = Q[e];
    if (!n)
      throw new Error(`Неизвестная модель: ${e}`);
    const t = n.api_key_env, s = await chrome.storage.local.get([t]);
    if (s[t])
      return s[t];
    const r = Re[t];
    return r || (console.warn(`[AI Client] API key not found for model ${e} (${t})`), null);
  } catch (n) {
    return console.error("[AI Client] Error getting API key:", n), null;
  }
}
async function ve(e, n, t) {
  var o, a;
  N || Fe();
  const s = performance.now(), r = {
    model: e,
    provider: "",
    startTime: s,
    retryCount: 0,
    rateLimited: !1,
    fallbackAttempted: !1,
    success: !1
  };
  try {
    if (!Object.keys(Q).includes(e))
      throw new Error(`Неизвестная модель: ${e}`);
    const c = Q[e];
    if (!c)
      throw new Error(`Неизвестная модель: ${e}`);
    r.provider = c.provider, N && N.addLog("ai_client", "info", "Starting AI API call", {
      model: e,
      provider: c.provider,
      promptLength: t.length
    });
    let i;
    switch (c.provider) {
      case "google":
        i = await Me(c, n, t, r);
        break;
      case "openai":
        i = await Ue(c, n, t, r);
        break;
      default:
        throw new Error(`Неподдерживаемый провайдер: ${c.provider}`);
    }
    r.endTime = performance.now(), r.responseTime = r.endTime - r.startTime, r.success = !0;
    try {
      c.provider === "google" && r.tokensUsed === void 0 && (r.tokensUsed = Math.ceil((t.length + i.length) / 4));
    } catch {
      r.tokensUsed = 0;
    }
    return le(r), i;
  } catch (c) {
    if (r.endTime = performance.now(), r.responseTime = r.endTime - r.startTime, r.success = !1, r.error = c.message, ((o = c.message) != null && o.includes("rate limit") || (a = c.message) != null && a.includes("quota") || c.status === 429) && (r.rateLimited = !0), le(r), !r.fallbackAttempted && shouldAttemptFallback(e, c))
      return await attemptFallbackCall(e, n, t);
    throw console.error("[AI Client] Error calling AI model:", c), new Error(`Ошибка при вызове модели ${e}: ${c.message}`);
  }
}
async function Me(e, n, t) {
  const s = `${e.endpoint}${e.model_name}:generateContent?key=${n}`, r = await fetch(s, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      contents: [{
        parts: [{
          text: t
        }]
      }],
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 2048
      }
    })
  });
  if (!r.ok) {
    const c = await r.text();
    throw new Error(`Google Gemini API error ${r.status}: ${c}`);
  }
  const o = await r.json();
  if (!o.candidates || !o.candidates[0] || !o.candidates[0].content)
    throw new Error("Неверный формат ответа от Google Gemini API");
  return o.candidates[0].content.parts[0].text || "Нет ответа от модели";
}
async function Ue(e, n, t) {
  const s = await fetch(e.endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${n}`
    },
    body: JSON.stringify({
      model: e.model_name,
      messages: [
        {
          role: "user",
          content: t
        }
      ],
      temperature: 0.7,
      max_tokens: 2048
    })
  });
  if (!s.ok) {
    const o = await s.text();
    throw new Error(`OpenAI API error ${s.status}: ${o}`);
  }
  const r = await s.json();
  if (!r.choices || !r.choices[0] || !r.choices[0].message)
    throw new Error("Неверный формат ответа от OpenAI API");
  return r.choices[0].message.content || "Нет ответа от модели";
}
var j;
(function(e) {
  e.Local = "local", e.Sync = "sync", e.Managed = "managed", e.Session = "session";
})(j || (j = {}));
var se;
(function(e) {
  e.ExtensionPagesOnly = "TRUSTED_CONTEXTS", e.ExtensionPagesAndContentScripts = "TRUSTED_AND_UNTRUSTED_CONTEXTS";
})(se || (se = {}));
const S = globalThis.chrome, ge = async (e, n) => {
  const t = (r) => typeof r == "function", s = (r) => (
    // Use ReturnType to infer the return type of the function and check if it's a Promise
    r instanceof Promise
  );
  return t(e) ? (s(e), e(n)) : e;
};
let ue = !1;
const me = (e) => {
  if (S && !S.storage[e])
    throw new Error(`"storage" permission in manifest.ts: "storage ${e}" isn't defined`);
}, ke = (e, n, t) => {
  var U, z;
  let s = null, r = !1, o = [];
  const a = (t == null ? void 0 : t.storageEnum) ?? j.Local, c = (t == null ? void 0 : t.liveUpdate) ?? !1, i = ((U = t == null ? void 0 : t.serialization) == null ? void 0 : U.serialize) ?? ((T) => T), E = ((z = t == null ? void 0 : t.serialization) == null ? void 0 : z.deserialize) ?? ((T) => T);
  ue === !1 && a === j.Session && (t == null ? void 0 : t.sessionAccessForContentScripts) === !0 && (me(a), S == null || S.storage[a].setAccessLevel({
    accessLevel: se.ExtensionPagesAndContentScripts
  }).catch((T) => {
    console.error(T), console.error("Please call .setAccessLevel() into different context, like a background script.");
  }), ue = !0);
  const m = async () => {
    me(a);
    const T = await (S == null ? void 0 : S.storage[a].get([e]));
    return T ? E(T[e]) ?? n : n;
  }, l = async (T) => {
    r || (s = await m()), s = await ge(T, s), await (S == null ? void 0 : S.storage[a].set({ [e]: i(s) })), O();
  }, u = (T) => (o = [...o, T], () => {
    o = o.filter((H) => H !== T);
  }), f = () => s, O = () => {
    o.forEach((T) => T());
  }, P = async (T) => {
    if (T[e] === void 0)
      return;
    const H = E(T[e].newValue);
    s !== H && (s = await ge(H, s), O());
  };
  return m().then((T) => {
    s = T, r = !0, O();
  }), c && (S == null || S.storage[a].onChanged.addListener(P)), {
    get: m,
    set: l,
    getSnapshot: f,
    subscribe: u
  };
}, de = ke("theme-storage-key", {
  theme: "system",
  isLight: Ce()
}, {
  storageEnum: j.Local,
  liveUpdate: !0
});
function Ce() {
  return typeof window < "u" && window.matchMedia ? window.matchMedia("(prefers-color-scheme: light)").matches : !0;
}
const He = {
  ...de,
  toggle: async () => {
    await de.set((e) => {
      let n;
      switch (e.theme) {
        case "light":
          n = "dark";
          break;
        case "dark":
          n = "system";
          break;
        case "system":
        default:
          n = "light";
          break;
      }
      const t = n === "system" ? Ce() : n === "light";
      return {
        theme: n,
        isLight: t
      };
    });
  }
}, Ke = (e, n) => n[e] ?? {
  enabled: !0,
  // По умолчанию плагин включен
  autorun: !1
  // По умолчанию автоматический запуск выключен
}, q = ke("plugin_settings", {}, {
  storageEnum: j.Local,
  liveUpdate: !1
  // Отключаем liveUpdate чтобы избежать бесконечных циклов
}), ye = async (e) => {
  const n = await q.get();
  return Ke(e, n);
};
console.log("[background] Initializing background imports...");
console.log("[background] Plugin chat API loaded");
console.log("[background] Host API loaded");
console.log("[background] Plugin manager loaded");
console.log("[background] Storage modules loaded");
console.log("[background] Starting Offscreen Document integration - REFACTORED BACKGROUND ARCHITECTURE");
const X = () => {
  var e;
  try {
    console.log("[background][OFFSCREEN DETECTION] ========== STARTING OFFSCREEN API FEATURE DETECTION =========="), console.log("[background][OFFSCREEN DETECTION] Timestamp:", (/* @__PURE__ */ new Date()).toISOString()), console.log("[background][OFFSCREEN DETECTION] Chrome User-Agent:", navigator.userAgent);
    const n = typeof chrome < "u";
    if (console.log("[background][OFFSCREEN DETECTION] Chrome object exists:", n), !n)
      return console.warn("[background][OFFSCREEN DETECTION] ❌ FAIL: Chrome API unavailable - extension running in unsupported environment"), console.warn("[background][OFFSCREEN DETECTION] Current context:", {
        globalThis: typeof globalThis,
        window: typeof window,
        self: typeof self,
        process: typeof _e
      }), !1;
    const t = typeof chrome.offscreen < "u";
    if (console.log("[background][OFFSCREEN DETECTION] chrome.offscreen property exists:", t), !t)
      return console.warn("[background][OFFSCREEN DETECTION] ❌ FAIL: chrome.offscreen is undefined - Chrome version < 109"), console.warn("[background][OFFSCREEN DETECTION] Available chrome API:", Object.keys(chrome).join(", ")), !1;
    const s = typeof chrome.offscreen.hasDocument == "function";
    if (console.log("[background][OFFSCREEN DETECTION] chrome.offscreen.hasDocument is function:", s), !s)
      return console.warn("[background][OFFSCREEN DETECTION] ❌ FAIL: chrome.offscreen.hasDocument is not a function"), console.warn("[background][OFFSCREEN DETECTION] chrome.offscreen properties:", Object.keys(chrome.offscreen).join(", ")), !1;
    const r = typeof chrome.offscreen.createDocument == "function";
    return console.log("[background][OFFSCREEN DETECTION] chrome.offscreen.createDocument is function:", r), r ? ((chrome.permissions ? typeof chrome.permissions.getAll == "function" : !0) || console.warn("[background][OFFSCREEN DETECTION] ⚠️ WARNING: Cannot verify permissions at runtime"), console.log("[background][OFFSCREEN DETECTION] ✅ SUCCESS: All Offscreen API checks passed"), console.log("[background][OFFSCREEN DETECTION] ========== DETECTION COMPLETE =========="), !0) : (console.warn("[background][OFFSCREEN DETECTION] ❌ FAIL: chrome.offscreen.createDocument is not a function"), console.warn("[background][OFFSCREEN DETECTION] chrome.offscreen methods:", Object.getOwnPropertyNames(chrome.offscreen).join(", ")), !1);
  } catch (n) {
    console.error("[background][OFFSCREEN DETECTION] ❌ CRITICAL ERROR during detection:", n), console.error("[background][OFFSCREEN DETECTION] Error message:", n.message), console.error("[background][OFFSCREEN DETECTION] Error stack:", n.stack), console.error("[background][OFFSCREEN DETECTION] Chrome version from UA:", ((e = navigator.userAgent.match(/Chrome\/(\d+)/)) == null ? void 0 : e[1]) || "Unknown");
    try {
      console.error("[background][OFFSCREEN DETECTION] Chrome API dump (limited):"), typeof chrome < "u" && (console.error("- chrome.runtime available:", typeof chrome.runtime), console.error("- chrome.permissions available:", typeof chrome.permissions), chrome.offscreen && console.error("- chrome.offscreen keys:", Object.keys(chrome.offscreen)));
    } catch (t) {
      console.error("[background][OFFSCREEN DETECTION] Error creating diagnostic dump:", t);
    }
    return !1;
  }
}, $e = 32 * 1024, qe = 50, v = /* @__PURE__ */ new Map();
function Ye(e, n = $e) {
  const t = [];
  for (let s = 0; s < e.length; s += n)
    t.push(e.slice(s, s + n));
  return t;
}
function We(e) {
  const n = v.get(e);
  if (!n)
    throw new Error(`Transfer ${e} not found`);
  const t = n.received.size, s = n.totalChunks;
  if (t !== s)
    throw new Error(`Transfer ${e} not complete: ${t}/${s} chunks acknowledged`);
  console.log(`[background][ASSEMBLY] Assembling HTML from ${n.chunks.length} chunks`), console.log(`[background][ASSEMBLY] Transfer ID: ${e}`), console.log(`[background][ASSEMBLY] Total chunks acknowledged: ${t}/${s}`);
  let r = "";
  for (let o = 0; o < n.chunks.length; o++) {
    const a = n.chunks[o];
    if (a != null && typeof a == "string")
      r += a;
    else
      throw new Error(`Invalid chunk at index ${o} in transfer ${e}`);
  }
  return console.log(`[background][ASSEMBLY] HTML assembled successfully: ${r.length} characters`), r;
}
async function Be(e, n, t, s) {
  const r = `${s}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, o = Ye(t);
  return console.log("[background][CHUNKING] Starting chunked HTML transfer:"), console.log("[background][CHUNKING] - Transfer ID:", r), console.log("[background][CHUNKING] - Total chunks:", o.length), console.log("[background][CHUNKING] - Original HTML size:", t.length, "chars"), new Promise((a, c) => {
    const i = setTimeout(() => {
      v.delete(r), c(new Error("HTML chunk transfer timeout"));
    }, 3e4);
    v.set(r, {
      chunks: o,
      received: /* @__PURE__ */ new Set(),
      totalChunks: o.length,
      metadata: { pluginId: e, pageKey: n, requestId: s, totalSize: t.length, timestamp: Date.now() },
      resolve: () => {
        clearTimeout(i), v.delete(r), a(r);
      },
      reject: (E) => {
        clearTimeout(i), v.delete(r), c(E);
      },
      timeout: i
    }), je(r);
  });
}
async function je(e) {
  const n = v.get(e);
  if (!n)
    throw console.error("[background][CHUNKING] Transfer not found:", e), new Error("Transfer not found");
  console.log(`[background][CHUNKING] Starting to send ${n.chunks.length} chunks (0-${n.chunks.length - 1})`);
  for (let t = 0; t < n.chunks.length; t++) {
    if (!v.has(e)) {
      console.log("[background][CHUNKING] Transfer cancelled or completed");
      return;
    }
    try {
      if (!n.chunks[t])
        throw console.error(`[background][CHUNKING] Chunk ${t} does not exist. Total chunks: ${n.chunks.length}`), new Error(`Chunk ${t} not found in transfer ${e}`);
      const s = {
        type: "HTML_CHUNK",
        transferId: e,
        chunkIndex: t,
        totalChunks: n.totalChunks,
        chunkData: n.chunks[t],
        metadata: n.metadata
      };
      console.log(`[background][CHUNKING] Sending chunk ${t}/${n.totalChunks - 1} (${n.chunks[t].length} chars)`), await chrome.runtime.sendMessage(s), await ze(e, t), t < n.chunks.length - 1 && await new Promise((r) => setTimeout(r, qe));
    } catch (s) {
      console.error(`[background][CHUNKING] Failed to send chunk ${t}:`, s), n.reject(s);
      return;
    }
  }
  try {
    await chrome.runtime.sendMessage({
      type: "HTML_CHUNK_COMPLETE",
      transferId: e,
      totalChunks: n.totalChunks
    }), console.log("[background][CHUNKING] All chunks sent successfully"), n.resolve();
  } catch (t) {
    console.error("[background][CHUNKING] Failed to send completion message:", t), n.reject(t);
  }
}
async function ze(e, n) {
  const t = v.get(e);
  if (!t)
    throw new Error("Transfer not found");
  const s = 5e3, r = Date.now();
  for (; !t.received.has(n); ) {
    if (Date.now() - r > s)
      throw new Error(`Timeout waiting for chunk ${n} acknowledgment`);
    await new Promise((o) => setTimeout(o, 100));
  }
  console.log(`[background][CHUNKING] Chunk ${n} acknowledged`);
}
function Ve(e) {
  const n = v.get(e.transferId);
  n ? e.received ? (n.received.add(e.chunkIndex), n.received.size === n.totalChunks && (console.log("[background][CHUNKING] All chunks acknowledged, transfer complete"), n.resolve())) : console.error(`[background][CHUNKING] Chunk ${e.chunkIndex} acknowledgment failed`) : console.warn("[background][CHUNKING] Acknowledgment for unknown transfer:", e.transferId);
}
const Xe = async (e) => {
  var n, t;
  if (console.warn("[background][LEGACY CHROME] ================= EXECUTING FALLBACK WORKFLOW ================="), console.warn("[background][LEGACY CHROME] Chrome version < 109 detected, offscreen API not supported"), console.warn("[background][LEGACY CHROME] Timestamp:", (/* @__PURE__ */ new Date()).toISOString()), console.warn("[background][LEGACY CHROME] User-Agent:", navigator.userAgent), console.warn("[background][LEGACY CHROME] Extension ID:", chrome.runtime.id), console.warn("[background][LEGACY CHROME] Legacy Chrome workaround: Skipping workflow execution with graceful degradation"), e.pluginId && e.pageKey) {
    if (console.warn(`[background][LEGACY CHROME] Cannot execute workflow for plugin: ${e.pluginId}`), console.warn(`[background][LEGACY CHROME] Page Key: ${e.pageKey}`), console.warn(`[background][LEGACY CHROME] Message ID: ${e.requestId || "N/A"}`), !w) {
      console.error("[background][LEGACY CHROME] pluginChatApi is not available");
      return;
    }
    const s = ((n = navigator.userAgent.match(/Chrome\/(\d+)/)) == null ? void 0 : n[1]) || "unknown", r = {
      role: "plugin",
      content: `⚠️ **Ограничение браузера**

Эта версия Google Chrome (${s}) не поддерживает необходимые API расширения (Offscreen Document API).

**Что произошло:**
- Расширение не смогло выполнить запланированную задачу для плагина "${e.pluginId || "N/A"}"
- Workflow будет пропущен для обеспечения стабильности работы

**Рекомендация:**
Обновите Google Chrome до версии 109 или новее для использования полной функциональности расширения.

**Технические детали:**
- Текущая версия: ${s}
- Требуемая версия: 109+
- API Status: Offscreen Document недоступен`,
      timestamp: Date.now()
    };
    try {
      await w.saveMessage(e.pluginId, e.pageKey, r), console.log("[background][LEGACY CHROME] ✅ Legacy Chrome warning saved to plugin chat"), console.log("[background][LEGACY CHROME] Message saved for plugin:", e.pluginId, "pageKey:", e.pageKey);
      const o = {
        role: "plugin",
        content: `[TRACKING] Legacy Chrome v${((t = navigator.userAgent.match(/Chrome\/(\d+)/)) == null ? void 0 : t[1]) || "unknown"} blocked workflow execution for compatibility reasons.`,
        timestamp: Date.now()
      };
      await w.saveMessage(e.pluginId, e.pageKey, o);
    } catch (o) {
      console.error("[background][LEGACY CHROME] ❌ CRITICAL: Failed to save legacy warning to chat:", o), console.error("[background][LEGACY CHROME] Error details:", {
        name: o.name,
        message: o.message,
        stack: o.stack
      });
      try {
        const a = {
          role: "plugin",
          content: "⚠️ Ошибка выполнения: устаревшая версия Chrome. Обновите браузер до версии 109+.",
          timestamp: Date.now()
        };
        await w.saveMessage(e.pluginId, e.pageKey, a), console.warn("[background][LEGACY CHROME] ⚠️ Fallback simple warning saved");
      } catch (a) {
        console.error("[background][LEGACY CHROME] ❌ CRITICAL: Even fallback message save failed:", a);
      }
    }
    console.warn("[background][LEGACY CHROME] ================= FALLBACK WORKFLOW COMPLETE =================");
  }
};
console.log("[background] All critical modules loaded, background initialization complete");
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 });
const Ee = async () => {
  if (!X())
    return console.log("[offscreen][manager] Offscreen API not supported, returning false"), !1;
  try {
    const e = await chrome.offscreen.hasDocument();
    return console.log("[offscreen][manager] Offscreen document exists:", e), e;
  } catch (e) {
    return console.error("[offscreen][manager] Error checking offscreen document:", e), !1;
  }
}, Je = async () => {
  if (!X())
    throw console.warn("[offscreen][manager] ❌ Chrome version does not support offscreen API (< 109)"), new Error("Offscreen API not supported in this Chrome version. Please update Chrome to version 109+.");
  const e = 3, n = 1e3;
  for (let t = 1; t <= e; t++)
    try {
      console.log(`[offscreen][manager] Attempt ${t}/${e}: Creating offscreen document...`), console.log("[offscreen][manager] Document config:", {
        url: "offscreen.html",
        reasons: ["WORKERS"],
        justification: "Pyodide Worker execution and MCP bridge delegation",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }), await chrome.offscreen.createDocument({
        url: "offscreen.html",
        reasons: ["WORKERS"],
        justification: "Pyodide Worker execution and MCP bridge delegation"
      }), console.log("[offscreen][manager] ✅ Offscreen document created successfully on attempt", t);
      try {
        if (await chrome.offscreen.hasDocument()) {
          console.log("[offscreen][manager] ✅ Document verification successful");
          return;
        } else
          throw new Error("Document creation verification failed - document does not exist");
      } catch (s) {
        console.warn("[offscreen][manager] ⚠️ Document verification failed, but creation seemed successful:", s);
        return;
      }
    } catch (s) {
      if (console.error(`[offscreen][manager] Attempt ${t}/${e} failed:`, s), console.error("[offscreen][manager] Error details:", {
        name: s.name,
        message: s.message,
        stack: s.stack
      }), t === e)
        throw console.error("[offscreen][manager] ❌ All attempts to create offscreen document failed"), new Error(`Failed to create offscreen document after ${e} attempts: ${s.message}`);
      console.log(`[offscreen][manager] Waiting ${n}ms before retry...`), await new Promise((r) => setTimeout(r, n));
    }
}, ee = async () => {
  console.log("[offscreen][manager] ===== ENSURING OFFSCREEN DOCUMENT AVAILABILITY ====="), console.log("[offscreen][manager] Timestamp:", (/* @__PURE__ */ new Date()).toISOString());
  try {
    const e = await Ee();
    if (console.log("[offscreen][manager] Offscreen document exists check result:", e), e)
      console.log("[offscreen][manager] ✅ Offscreen document already exists and is ready");
    else {
      if (console.log("[offscreen][manager] ❌ Offscreen document not found, creating new document..."), console.log("[offscreen][manager] This may take a few seconds..."), await Je(), console.log("[offscreen][manager] ✅ Offscreen document creation completed"), !await Ee())
        throw console.error("[offscreen][manager] ❌ CRITICAL: Document verification failed after creation"), new Error("Offscreen document creation verification failed");
      console.log("[offscreen][manager] ✅ Offscreen document verification successful");
    }
    console.log("[offscreen][manager] ===== OFFSCREEN DOCUMENT ENSURANCE COMPLETE =====");
  } catch (e) {
    console.error("[offscreen][manager] ❌ CRITICAL ERROR in ensureOffscreenDocument:", e), console.error("[offscreen][manager] Error details:", {
      name: e.name,
      message: e.message,
      stack: e.stack
    });
    try {
      console.log("[offscreen][manager] 🔄 Attempting recovery by forcing document recreation..."), await chrome.runtime.reload();
    } catch (n) {
      console.error("[offscreen][manager] ❌ Recovery attempt failed:", n);
    }
    throw e;
  }
}, Ze = async (e) => {
  try {
    return (await ye(e)).enabled ? { success: !0 } : (console.log(`[background] Plugin ${e} is disabled, not running`), { success: !1, reason: "Plugin is disabled" });
  } catch (n) {
    return console.error(`[background] Error running plugin ${e}:`, n), { error: n.message };
  }
}, Qe = async (e, n, t) => {
  const s = await q.get(), r = s[e] || { enabled: !0, autorun: !1 };
  return r[n] = t, n === "enabled" && !t && (r.autorun = !1), await q.set({
    ...s,
    [e]: r
  }), console.log(`[background] Updated plugin setting for ${e}:`, n, "=", t), { success: !0 };
}, B = (e, n) => {
  chrome.runtime.sendMessage({
    type: "PLUGIN_CHAT_UPDATED",
    pluginId: e,
    pageKey: n
  });
}, K = {}, er = (e) => {
  const n = e.pluginId;
  K[n] || (K[n] = []), K[n].push({ ...e, timestamp: Date.now() }), K[n].length > 500 && K[n].shift();
};
chrome.runtime.onMessage.addListener(
  async (e, n, t) => {
    var s;
    if (console.log("[background] Got message:", e, "from:", (n == null ? void 0 : n.origin) || (n == null ? void 0 : n.id) || "unknown"), console.log("[background] Message timestamp:", (/* @__PURE__ */ new Date()).toISOString()), console.log("[background] Sender details:", {
      id: n == null ? void 0 : n.id,
      origin: n == null ? void 0 : n.origin,
      url: n == null ? void 0 : n.url,
      tab: n == null ? void 0 : n.tab,
      frameId: n == null ? void 0 : n.frameId
    }), typeof e == "object" && e !== null && "source" in e && e.source === "app-host-api" && "command" in e && "data" in e)
      return rr(e, t), !0;
    if (typeof e == "object" && e !== null && "type" in e) {
      const r = e;
      if (console.log("[background] ===== MAIN MESSAGE HANDLER ====="), console.log("[background] Processing message type:", r.type), console.log("[background] Sender origin:", (n == null ? void 0 : n.origin) || "none"), console.log("[background] Sender ID:", (n == null ? void 0 : n.id) || "none"), console.log("[background] Message content preview:", JSON.stringify(e).substring(0, 200) + "..."), console.log("[background] Timestamp:", (/* @__PURE__ */ new Date()).toISOString()), r.type === "TEST_SYNC") {
        console.log("[background] Processing TEST_SYNC request"), console.log("[background] TEST_SYNC timestamp:", (/* @__PURE__ */ new Date()).toISOString());
        const o = { success: !0, message: "Test sync response", timestamp: Date.now() };
        return console.log("[background] TEST_SYNC sending response:", o), t(o), console.log("[background] TEST_SYNC response sent"), !0;
      }
      if (r.type === "RUN_WORKFLOW" && (console.log("[background][DEBUG] ===== MESSAGE TYPE IS RUN_WORKFLOW ====="), console.log("[background][DEBUG] RUN_WORKFLOW message detected:", {
        type: r.type,
        pluginId: r.pluginId,
        pageKey: r.pageKey,
        hasPluginId: !!r.pluginId,
        hasPageKey: !!r.pageKey,
        fullMessage: JSON.stringify(r, null, 2)
      })), r.type === "PING")
        return console.log("[background] Processing PING request"), console.log("[background] PING timestamp:", (/* @__PURE__ */ new Date()).toISOString()), t({ pong: !0, timestamp: Date.now() }), console.log("[background] PING response sent"), !0;
      if (r.type === "TEST_PYODIDE_DIRECT") {
        console.log("[background][TEST_PYODIDE_DIRECT] Processing direct Pyodide test request"), console.log("[background][TEST_PYODIDE_DIRECT] Python code to execute:", r.pythonCode);
        try {
          (async () => {
            try {
              const o = await or(r);
              console.log("[background][TEST_PYODIDE_DIRECT] Test completed with result:", o), t(o || {
                success: !1,
                error: "No response received from test execution",
                timestamp: Date.now()
              });
            } catch (o) {
              console.error("[background][TEST_PYODIDE_DIRECT] Test failed:", o), t({
                success: !1,
                error: o.message,
                timestamp: Date.now()
              });
            }
          })();
        } catch (o) {
          console.error("[background][TEST_PYODIDE_DIRECT] Critical error in async handler setup:", o), t({
            success: !1,
            error: o.message,
            timestamp: Date.now()
          });
        }
        return !0;
      }
      if (r.type === "INITIALIZE_PYODIDE_MANUAL_TEST") {
        console.log("[background][INITIALIZE_PYODIDE_MANUAL_TEST] Initializing Pyodide for manual testing");
        try {
          (async () => {
            try {
              await ee();
              const o = await chrome.runtime.sendMessage({
                type: "INITIALIZE_PYODIDE",
                requestId: r.requestId,
                timestamp: r.timestamp
              });
              t({
                success: (o == null ? void 0 : o.success) || !0,
                result: "Pyodide initialized in offscreen document",
                timestamp: Date.now()
              });
            } catch (o) {
              console.error("[background][INITIALIZE_PYODIDE_MANUAL_TEST] Initialization failed:", o), t({
                success: !1,
                error: o.message,
                timestamp: Date.now()
              });
            }
          })();
        } catch (o) {
          console.error("[background][INITIALIZE_PYODIDE_MANUAL_TEST] Critical error in async handler setup:", o), t({
            success: !1,
            error: o.message,
            timestamp: Date.now()
          });
        }
        return !0;
      }
      if (r.type === "EXECUTE_PYTHON_TEST_CODE") {
        console.log("[background][EXECUTE_PYTHON_TEST_CODE] Executing Python test code"), console.log("[background][EXECUTE_PYTHON_TEST_CODE] Test name:", r.testName), console.log("[background][EXECUTE_PYTHON_TEST_CODE] Code:", r.code);
        try {
          (async () => {
            try {
              const o = await chrome.runtime.sendMessage({
                type: "EXECUTE_PYTHON_CODE",
                code: r.code,
                testName: r.testName,
                requestId: r.requestId,
                timestamp: r.timestamp
              });
              t({
                success: (o == null ? void 0 : o.success) || !1,
                result: o == null ? void 0 : o.result,
                error: o == null ? void 0 : o.error,
                timestamp: Date.now(),
                executionTime: Date.now() - (r.timestamp || 0)
              });
            } catch (o) {
              console.error("[background][EXECUTE_PYTHON_TEST_CODE] Execution failed:", o), t({
                success: !1,
                error: o.message,
                timestamp: Date.now()
              });
            }
          })();
        } catch (o) {
          console.error("[background][EXECUTE_PYTHON_TEST_CODE] Critical error in async handler setup:", o), t({
            success: !1,
            error: o.message,
            timestamp: Date.now()
          });
        }
        return !0;
      }
      if (r.type === "EXECUTE_PYTHON_ERROR_TEST") {
        console.log("[background][EXECUTE_PYTHON_ERROR_TEST] Executing Python error test"), console.log("[background][EXECUTE_PYTHON_ERROR_TEST] Test name:", r.testName);
        try {
          (async () => {
            try {
              const o = await chrome.runtime.sendMessage({
                type: "EXECUTE_PYTHON_CODE",
                code: r.code,
                testName: r.testName,
                isErrorTest: !0,
                requestId: r.requestId,
                timestamp: r.timestamp
              });
              t({
                success: (o == null ? void 0 : o.success) || !1,
                result: o == null ? void 0 : o.result,
                error: o == null ? void 0 : o.error,
                timestamp: Date.now()
              });
            } catch (o) {
              console.error("[background][EXECUTE_PYTHON_ERROR_TEST] Error test failed:", o), t({
                success: !1,
                error: o.message,
                timestamp: Date.now()
              });
            }
          })();
        } catch (o) {
          console.error("[background][EXECUTE_PYTHON_ERROR_TEST] Critical error in async handler setup:", o), t({
            success: !1,
            error: o.message,
            timestamp: Date.now()
          });
        }
        return !0;
      }
      if (r.type === "GET_PLUGINS") {
        console.log("[background] Processing GET_PLUGINS request from sender:", n), console.log("[background] GET_PLUGINS message timestamp:", (/* @__PURE__ */ new Date()).toISOString());
        try {
          (async () => {
            var o;
            try {
              console.log("[background] processGetPlugins started, timestamp:", (/* @__PURE__ */ new Date()).toISOString()), console.log("[background] Sender details:", {
                id: n == null ? void 0 : n.id,
                origin: n == null ? void 0 : n.origin,
                url: n == null ? void 0 : n.url,
                tab: (o = n == null ? void 0 : n.tab) == null ? void 0 : o.id,
                frameId: n == null ? void 0 : n.frameId
              }), console.log("[background] Getting available plugins...");
              const a = Date.now(), [c, i] = await Promise.all([
                ae(),
                q.get()
              ]), E = Date.now() - a;
              if (console.log(`[background] Data fetched in ${E}ms`), console.log("[background] getAvailablePlugins result:", c), console.log("[background] Plugins count:", (c == null ? void 0 : c.length) || "undefined"), console.log("[background] Plugin settings:", i), console.log("[background] Settings type:", typeof i), !c || !Array.isArray(c)) {
                console.error("[background] getAvailablePlugins returned invalid data:", c), chrome.runtime.sendMessage({
                  type: "GET_PLUGINS_RESPONSE",
                  error: "Invalid plugins data from getAvailablePlugins",
                  requestId: r.requestId
                }), t({ success: !1, timestamp: Date.now() });
                return;
              }
              const m = c.map((u) => {
                console.log("[background] Processing plugin:", u.id, u.name);
                const f = i[u.id] || {
                  enabled: !0,
                  autorun: !1
                };
                return console.log("[background] Plugin settings for", u.id, ":", f), {
                  ...u,
                  settings: f
                };
              });
              console.log("[background] Final plugins data:", m.length, "plugins"), console.log("[background] Final plugins data details:", m.map((u) => ({ id: u.id, name: u.name, settings: u.settings })));
              const l = {
                type: "GET_PLUGINS_RESPONSE",
                plugins: m,
                requestId: r.requestId
                // Добавляем requestId для сопоставления
              };
              console.log("[background] Broadcasting GET_PLUGINS_RESPONSE:", l), console.log("[background] About to broadcast, timestamp:", (/* @__PURE__ */ new Date()).toISOString()), chrome.runtime.sendMessage(l), console.log("[background] Successfully sent plugins response, timestamp:", (/* @__PURE__ */ new Date()).toISOString()), t({ success: !0, timestamp: Date.now() });
            } catch (a) {
              console.error("[background] Error processing GET_PLUGINS:", a), console.error("[background] Error details:", {
                message: a.message,
                stack: a.stack,
                name: a.name
              }), chrome.runtime.sendMessage({
                type: "GET_PLUGINS_RESPONSE",
                error: a.message,
                requestId: r.requestId
              }), console.log("[background] Sent error response broadcast"), t({ success: !1, timestamp: Date.now() });
            }
          })();
        } catch (o) {
          console.error("[background][GET_PLUGINS] Critical error in async handler setup:", o), t({
            error: o.message,
            requestId: r.requestId
          });
        }
        return !0;
      }
      if (console.log("[background][DEBUG] ===== MESSAGE RECEIVED ====="), console.log("[background][DEBUG] Message type:", r.type), console.log("[background][DEBUG] Message pluginId:", r.pluginId), console.log("[background][DEBUG] Message pageKey:", r.pageKey), console.log("[background][DEBUG] Full message object:", JSON.stringify(r, null, 2)), console.log("[background][DEBUG] Timestamp:", (/* @__PURE__ */ new Date()).toISOString()), r.type === "RUN_WORKFLOW") {
        console.log("[background][OFFSCREEN DELEGATION] ===== RUN_WORKFLOW REQUEST RECEIVED ====="), console.log("[background][OFFSCREEN DELEGATION] Plugin ID:", r.pluginId), console.log("[background][OFFSCREEN DELEGATION] Page Key:", r.pageKey), console.log("[background][OFFSCREEN DELEGATION] Request timestamp:", (/* @__PURE__ */ new Date()).toISOString()), console.log("[background][DEBUG] Condition checks:"), console.log("[background][DEBUG] - msg.type === RUN_WORKFLOW:", r.type === "RUN_WORKFLOW"), console.log("[background][DEBUG] - msg.pluginId exists:", !!r.pluginId), console.log("[background][DEBUG] - msg.pageKey exists:", !!r.pageKey);
        try {
          console.log("[background][DEBUG] Starting async handler for RUN_WORKFLOW"), (async () => {
            console.log("[background][DEBUG] Inside async block, checking required fields..."), console.log("[background][DEBUG] msg.pluginId:", r.pluginId, "msg.pageKey:", r.pageKey);
            try {
              if (!r.pluginId) {
                console.error("[background][OFFSCREEN DELEGATION] Missing required field: pluginId"), t({ error: "Отсутствует обязательное поле: pluginId" });
                return;
              }
              console.log("[background][OFFSCREEN DELEGATION] Querying active tab...");
              const a = (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0];
              if (!a || !a.id) {
                console.log("[background][OFFSCREEN DELEGATION][ERROR] No active tab found"), t({ error: "Не найдена активная вкладка" });
                return;
              }
              console.log("[background][OFFSCREEN DELEGATION] Active tab details:", {
                url: a.url,
                tabId: a.id,
                title: a.title
              });
              const c = b(a.url || "");
              console.log("[background][OFFSCREEN DELEGATION] Generated pageKey from tab URL:", c), console.log("[background][OFFSCREEN DELEGATION] Active tab URL:", a.url), console.log("[background][OFFSCREEN DELEGATION] Extracting page HTML...");
              let i = "";
              try {
                const l = await chrome.scripting.executeScript({
                  target: { tabId: a.id },
                  func: () => document.documentElement.outerHTML
                });
                if (l && l[0] && l[0].result && typeof l[0].result == "string")
                  i = l[0].result, console.log("[background][OFFSCREEN DELEGATION] ✓ HTML extracted successfully:", i.length, "chars"), i.length < 100 && console.warn("[background][OFFSCREEN DELEGATION][WARNING] HTML too short:", i.length, "chars");
                else {
                  console.error("[background][OFFSCREEN DELEGATION][ERROR] Invalid or empty HTML result:", {
                    hasResults: !!l,
                    hasFirstResult: !!(l && l[0]),
                    hasResultProp: !!(l && l[0] && "result" in l[0]),
                    resultType: l && l[0] ? typeof l[0].result : "no result"
                  }), t({ error: "Не удалось получить содержимое страницы или получен пустой результат" });
                  return;
                }
              } catch (l) {
                console.error("[background][OFFSCREEN DELEGATION][ERROR] HTML extraction failed:", l), t({ error: `Не удалось получить HTML страницы: ${l.message}` });
                return;
              }
              if (console.log("[background][OFFSCREEN DELEGATION] Checking plugin settings..."), !(await ye(r.pluginId)).enabled) {
                console.log("[background][OFFSCREEN DELEGATION][INFO] Plugin disabled, aborting"), t({ error: "Плагин отключен" });
                return;
              }
              if (console.log("[background][OFFSCREEN DELEGATION][SUCCESS] Plugin is enabled, proceeding"), console.log("[background][OFFSCREEN DELEGATION] ===== ENSURING OFFSCREEN DOCUMENT ====="), !X()) {
                console.log("[background][OFFSCREEN DELEGATION] Offscreen API not supported, using fallback...");
                const l = {
                  type: "EXECUTE_WORKFLOW",
                  pluginId: r.pluginId,
                  pageKey: c,
                  data: {
                    pageHtml: i,
                    pageKey: c,
                    pluginId: r.pluginId
                  }
                };
                await Xe(l), t({ success: !0 });
                return;
              }
              await ee(), console.log("[background][OFFSCREEN DELEGATION] ===== DELEGATING TO OFFSCREEN ====="), console.log("[background][OFFSCREEN DELEGATION] Preparing workflow payload...");
              const m = r.requestId || `workflow_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
              if (console.log("[background][OFFSCREEN DELEGATION] HTML size check:", i.length, "chars"), console.log("[background][OFFSCREEN DELEGATION] Chunking threshold: 64000 chars"), i.length > 64e3) {
                console.log("[background][OFFSCREEN DELEGATION] Large HTML detected, using chunking approach"), console.log("[background][OFFSCREEN DELEGATION][DEBUG] HTML size:", i.length, "chars (>${64000})");
                try {
                  if (typeof i != "string" || i.length === 0)
                    throw new Error("Invalid HTML data for chunking");
                  const l = await Be(r.pluginId, c, i, m);
                  console.log("[background][OFFSCREEN DELEGATION] All chunks sent, now assembling HTML from chunks...");
                  let u = "";
                  try {
                    u = We(l), console.log("[background][OFFSCREEN DELEGATION] HTML assembled successfully:", u.length, "characters");
                    const P = i.length, U = u.length;
                    console.log(`[background][OFFSCREEN DELEGATION] Original HTML length: ${P}`), console.log(`[background][OFFSCREEN DELEGATION] Assembled HTML length: ${U}`), Math.abs(P - U) > 1e3 && console.warn("[background][OFFSCREEN DELEGATION] WARNING: Large difference in HTML length detected!");
                  } catch (P) {
                    console.error("[background][OFFSCREEN DELEGATION] HTML assembly failed:", P), t({ error: `HTML assembly failed: ${P.message}` });
                    return;
                  }
                  const f = {
                    type: "EXECUTE_WORKFLOW",
                    pluginId: r.pluginId,
                    pageKey: c,
                    requestId: m,
                    transferId: l,
                    // <-- ДОБАВИТЬ transferId
                    useChunks: !1,
                    // <-- Больше не используем чанки, HTML собран
                    pageHtml: u,
                    // <-- Собрать HTML из чанков с помощью assembleHtmlFromChunks
                    timestamp: Date.now()
                  };
                  if (console.log("[background][OFFSCREEN DELEGATION] Sending workflow start command after chunks assembly..."), console.log("[background][DEBUG] Workflow command payload:", JSON.stringify({
                    ...f,
                    pageHtml: `${u.length} chars assembled`
                  }, null, 2)), !u || u.length === 0) {
                    console.error("[background][OFFSCREEN DELEGATION] CRITICAL: Assembled HTML is empty!"), t({ error: "Assembled HTML is empty after chunk processing" });
                    return;
                  }
                  u.length < 1e3 ? (console.warn("[background][OFFSCREEN DELEGATION] WARNING: Assembled HTML seems too small:", u.length, "chars"), console.warn("[background][OFFSCREEN DELEGATION] First 500 chars:", u.substring(0, 500))) : console.log(`[background][OFFSCREEN DELEGATION] ✅ HTML validation passed: ${u.length} characters ready`);
                  const O = await chrome.runtime.sendMessage(f);
                  console.log("[background][OFFSCREEN DELEGATION] Workflow command sent, result:", O), console.log("[background][DEBUG] About to check sendResponse function...");
                } catch (l) {
                  console.error("[background][OFFSCREEN DELEGATION] Chunking failed:", l), t({ error: `Failed to send large HTML data: ${l.message}` });
                  return;
                }
              } else {
                console.log("[background][OFFSCREEN DELEGATION] Small HTML, using direct transmission"), console.log("[background][OFFSCREEN DELEGATION] Small HTML, using direct transmission");
                const l = {
                  type: "EXECUTE_WORKFLOW",
                  pluginId: r.pluginId,
                  pageKey: c,
                  pageHtml: i,
                  requestId: m,
                  transferId: m,
                  // <-- ДОБАВИТЬ transferId
                  useChunks: !1,
                  // <-- ДОБАВИТЬ useChunks для консистентности
                  timestamp: Date.now()
                };
                console.log("[background][OFFSCREEN DELEGATION] Execution payload prepared:", {
                  ...l,
                  pageHtml: `${i.length} chars`
                }), console.log("[background][DEBUG] Full workflow payload:", JSON.stringify({
                  ...l,
                  pageHtml: i.substring(0, 100) + "..."
                }, null, 2)), console.log("[background][OFFSCREEN DELEGATION] Sending to offscreen..."), console.log("[background][DEBUG] Sending chrome.runtime.sendMessage with payload above...");
                const u = await chrome.runtime.sendMessage(l);
                console.log("[background][DEBUG] chrome.runtime.sendMessage completed, result:", u);
              }
              if (console.log("[background][OFFSCREEN DELEGATION] ===== OFFSCREEN EXECUTION COMPLETED ====="), console.log("[background][OFFSCREEN DELEGATION] Result received:", result), typeof t != "function") {
                console.warn("[background][OFFSCREEN DELEGATION] sendResponse is not a function - response channel may be closed");
                return;
              }
              if (result && result.success) {
                console.log("[background][OFFSCREEN DELEGATION] Sending success response"), console.log("[background][DEBUG] sendResponse function before call:", typeof t);
                const l = { success: !0 };
                console.log("[background][DEBUG] Success response object:", l), t(l), console.log("[background][DEBUG] Success sendResponse called - no more execution expected after this");
              } else {
                const l = (result == null ? void 0 : result.error) || "Unknown execution error";
                console.log("[background][OFFSCREEN DELEGATION] Sending error response:", l), console.log("[background][DEBUG] sendResponse function before call:", typeof t);
                const u = { error: l };
                console.log("[background][DEBUG] Error response object:", u), t(u), console.log("[background][DEBUG] Error sendResponse called - no more execution expected after this");
              }
            } catch (o) {
              console.error("[background][OFFSCREEN DELEGATION] Error in delegation:", o), t({ error: o.message });
            }
          })();
        } catch (o) {
          console.error("[background][OFFSCREEN DELEGATION] Critical error in async handler setup:", o), t({ error: o.message });
        }
        return !0;
      }
      if (r.type === "UPDATE_PLUGIN_SETTING" && r.pluginId && r.setting !== void 0 && r.value !== void 0) {
        const { pluginId: o, setting: a, value: c } = r;
        return console.log("[background] Processing UPDATE_PLUGIN_SETTING request for:", o, a, c), (async () => {
          try {
            await Qe(o, a, c), t({ success: !0 });
          } catch (i) {
            console.error("[background] Error in UPDATE_PLUGIN_SETTING:", i), t({ error: i.message });
          }
        })(), !0;
      }
      if (r.type === "GET_PLUGIN_SETTINGS")
        return console.log("[background] Processing GET_PLUGIN_SETTINGS request"), (async () => {
          try {
            const o = await q.get();
            console.log("[background] Plugin settings:", o), t(o);
          } catch (o) {
            console.error("[background] Error getting plugin settings:", o), t({ error: o.message });
          }
        })(), !0;
      if (r.type === "GET_PLUGIN_CHAT" && r.pluginId && r.pageKey) {
        const { pluginId: o, pageKey: a, messageId: c } = r, i = `${o}::${b(a)}`;
        return console.log("[background] GET_PLUGIN_CHAT: начало обработки", {
          pluginId: o,
          pageKey: a,
          messageId: c,
          chatKey: i,
          normalizedPageKey: b(a),
          timestamp: Date.now()
        }), (async () => {
          var E, m;
          try {
            const l = await w.getOrLoadChat(i);
            if (console.log("[background] GET_PLUGIN_CHAT: результат getOrLoadChat", {
              chat: l,
              chatType: typeof l,
              hasChat: !!l,
              messagesLength: (E = l == null ? void 0 : l.messages) == null ? void 0 : E.length,
              chatKey: i,
              pageKey: a
            }), !l) {
              console.log("[background] GET_PLUGIN_CHAT: чат не найден, возвращаем пустой массив сообщений"), chrome.runtime.sendMessage({
                type: "GET_PLUGIN_CHAT_RESPONSE",
                messageId: c,
                response: {
                  messages: [],
                  chatKey: i,
                  pluginId: o,
                  pageKey: a
                }
              });
              return;
            }
            let u = l;
            l && Array.isArray(l.messages) && l.messages.length > 50 && (u = { ...l, messages: l.messages.slice(-50) }, console.log("[background] GET_PLUGIN_CHAT: обрезан до 50 сообщений", {
              originalLength: l.messages.length,
              newLength: u.messages.length
            }));
            try {
              const f = JSON.parse(JSON.stringify(u));
              console.log("[background] GET_PLUGIN_CHAT: сериализация успешна", {
                serializable: f,
                serializableType: typeof f,
                serializableKeys: Object.keys(f || {}),
                serializableMessages: f == null ? void 0 : f.messages,
                isArrayMessages: Array.isArray(f == null ? void 0 : f.messages),
                chatKey: i,
                pageKey: a
              });
              const O = {
                messages: (f == null ? void 0 : f.messages) || [],
                chatKey: f == null ? void 0 : f.chatKey,
                pluginId: f == null ? void 0 : f.pluginId,
                pageKey: f == null ? void 0 : f.pageKey
              };
              console.log("[background] GET_PLUGIN_CHAT: отправляем ответ", {
                response: O,
                responseType: typeof O,
                responseKeys: Object.keys(O),
                responseMessagesLength: (m = O.messages) == null ? void 0 : m.length,
                messageId: c,
                timestamp: Date.now()
              }), chrome.runtime.sendMessage({
                type: "GET_PLUGIN_CHAT_RESPONSE",
                messageId: c,
                response: O
              });
            } catch (f) {
              console.error("[background] GET_PLUGIN_CHAT: Ошибка сериализации чата:", {
                error: f,
                safeChat: u,
                safeChatType: typeof u,
                safeChatKeys: Object.keys(u || {}),
                timestamp: Date.now()
              }), chrome.runtime.sendMessage({
                type: "GET_PLUGIN_CHAT_RESPONSE",
                messageId: c,
                response: { error: "serialization failed", details: String(f) }
              });
            }
          } catch (l) {
            console.error("[background] GET_PLUGIN_CHAT: Ошибка в getOrLoadChat:", {
              error: l,
              errorMessage: String(l),
              errorStack: l.stack,
              pluginId: o,
              pageKey: a,
              chatKey: i,
              timestamp: Date.now()
            }), chrome.runtime.sendMessage({
              type: "GET_PLUGIN_CHAT_RESPONSE",
              messageId: c,
              response: { error: String(l) }
            });
          }
        })(), !0;
      }
      if (r.type === "CREATE_PLUGIN_CHAT" && r.pluginId && r.pageKey) {
        const { pluginId: o, pageKey: a } = r, c = b(a);
        return console.log("[background] CREATE_PLUGIN_CHAT pageKey:", a, "norm:", c), (async () => {
          try {
            const i = await w.createChatIfNotExists(o, c);
            console.log("[background] sendResponse(CREATE_PLUGIN_CHAT):", i), t(i), B(o, c);
          } catch (i) {
            console.error("[background] Error creating plugin chat:", i), t({ error: String(i) });
          }
        })(), !0;
      }
      if (r.type === "SAVE_PLUGIN_CHAT_DRAFT" && r.pluginId && r.pageKey && r.draftText !== void 0) {
        const { pluginId: o, pageKey: a, draftText: c } = r, i = b(a);
        return console.log("[background] SAVE_PLUGIN_CHAT_DRAFT pageKey:", a, "norm:", i), (async () => {
          try {
            await w.saveDraft(o, i, c), console.log("[background] sendResponse(SAVE_PLUGIN_CHAT_DRAFT):", { success: !0 }), t({ success: !0 });
          } catch (E) {
            console.error("[background] Error saving plugin chat draft:", E), t({ error: String(E) });
          }
        })(), !0;
      }
      if (r.type === "GET_PLUGIN_CHAT_DRAFT" && r.pluginId && r.pageKey) {
        const { pluginId: o, pageKey: a } = r, c = b(a);
        return console.log("[background] GET_PLUGIN_CHAT_DRAFT pageKey:", a, "norm:", c), (async () => {
          try {
            const i = await w.getDraft(o, c);
            console.log("[background] sendResponse(GET_PLUGIN_CHAT_DRAFT):", { draftText: i }), t({ draftText: i });
          } catch (i) {
            console.error("[background] Error getting plugin chat draft:", i), t({ error: String(i) });
          }
        })(), !0;
      }
      if (r.type === "SAVE_PLUGIN_CHAT_MESSAGE" && r.pluginId && r.pageKey && r.message) {
        const { pluginId: o, pageKey: a, message: c, messageId: i } = r, E = b(a);
        return console.log("[background] SAVE_PLUGIN_CHAT_MESSAGE: начало", {
          pluginId: o,
          pageKey: a,
          messageId: i,
          normPageKey: E,
          chatMsg: c,
          chatMsgType: typeof c,
          chatMsgKeys: Object.keys(c),
          timestamp: Date.now()
        }), (async () => {
          try {
            const m = await w.saveMessage(o, E, c);
            console.log("[background] SAVE_PLUGIN_CHAT_MESSAGE: saveMessage результат", {
              result: m,
              success: m.success,
              pluginId: o,
              pageKey: a,
              normPageKey: E,
              timestamp: Date.now()
            }), await w.deleteDraft(o, E), console.log("[background] SAVE_PLUGIN_CHAT_MESSAGE: deleteDraft завершен", {
              result: m,
              pluginId: o,
              pageKey: a,
              normPageKey: E,
              timestamp: Date.now()
            }), chrome.runtime.sendMessage({
              type: "SAVE_PLUGIN_CHAT_MESSAGE_RESPONSE",
              messageId: i,
              success: !0,
              pluginId: o,
              pageKey: E,
              timestamp: Date.now()
            }), B(o, E);
          } catch (m) {
            console.error("[background] SAVE_PLUGIN_CHAT_MESSAGE: ошибка", {
              error: m,
              errorMessage: String(m),
              errorStack: m.stack,
              pluginId: o,
              pageKey: a,
              normPageKey: E,
              timestamp: Date.now()
            }), chrome.runtime.sendMessage({
              type: "SAVE_PLUGIN_CHAT_MESSAGE_RESPONSE",
              messageId: i,
              success: !1,
              error: String(m),
              pluginId: o,
              pageKey: E,
              timestamp: Date.now()
            });
          }
        })(), !0;
      }
      if (r.type === "DELETE_PLUGIN_CHAT" && r.pluginId && r.pageKey) {
        const { pluginId: o, pageKey: a, messageId: c } = r, i = b(a);
        return console.log("[background] DELETE_PLUGIN_CHAT pageKey:", a, "messageId:", c, "norm:", i), (async () => {
          try {
            await w.deleteChat(o, i), chrome.runtime.sendMessage({
              type: "DELETE_PLUGIN_CHAT_RESPONSE",
              messageId: c,
              success: !0,
              pluginId: o,
              pageKey: i,
              timestamp: Date.now()
            }), B(o, i);
          } catch (E) {
            console.error("[background] Error deleting plugin chat:", E), chrome.runtime.sendMessage({
              type: "DELETE_PLUGIN_CHAT_RESPONSE",
              messageId: c,
              success: !1,
              error: String(E),
              pluginId: o,
              pageKey: i,
              timestamp: Date.now()
            });
          }
        })(), !0;
      }
      if (r.type === "LIST_PLUGIN_CHATS" && r.pluginId) {
        const { pluginId: o } = r;
        return console.log("[background] Listing chats for plugin:", o), (async () => {
          try {
            const a = await w.listChatsForPlugin(o);
            console.log("[background] Chats found:", a), t(a);
          } catch (a) {
            console.error("[background] Error listing chats:", a), t([]);
          }
        })(), !0;
      }
      if (r.type === "LIST_PLUGIN_CHAT_DRAFTS" && r.pluginId) {
        const { pluginId: o } = r;
        return console.log("[background] Listing drafts for plugin:", o), (async () => {
          try {
            const a = await w.listDraftsForPlugin(o);
            console.log("[background] Drafts found:", a), t(a);
          } catch (a) {
            console.error("[background] Error listing drafts:", a), t([]);
          }
        })(), !0;
      }
      if (r.type === "LOG_EVENT" && r.pluginId && typeof r.message == "string")
        return er({
          pluginId: r.pluginId,
          pageKey: r.pageKey,
          level: r.level || "info",
          stepId: r.stepId,
          message: r.message,
          data: r.logData
        }), chrome.runtime.sendMessage({
          type: "PLUGIN_LOG_UPDATED",
          pluginId: r.pluginId,
          pageKey: r.pageKey
        }), t({ success: !0 }), !0;
      if (r.type === "LIST_PLUGIN_LOGS" && r.pluginId)
        return t(K[r.pluginId] || []), !0;
      if (r.type === "LIST_ALL_PLUGIN_LOGS")
        return t(K), !0;
      if (r.type === "GET_ACTIVE_TAB_URL") {
        try {
          const o = await chrome.tabs.query({ active: !0, currentWindow: !0 });
          (s = o[0]) != null && s.url ? t({ url: o[0].url }) : t({ error: "Active tab not found" });
        } catch (o) {
          t({ error: o.message });
        }
        return !0;
      }
    }
    return console.log("[background][DEBUG] Main handler finished processing, checking final return..."), console.log("[background] Returning true to keep channel open, timestamp:", (/* @__PURE__ */ new Date()).toISOString()), !0;
  }
);
const rr = async (e, n) => {
  try {
    switch (e.command) {
      case "getElements": {
        const t = await fe(), s = e.data, r = await chrome.scripting.executeScript({
          target: { tabId: t.id },
          func: (o) => o.map((a) => {
            const c = document.querySelectorAll(a);
            return Array.from(c).map((i) => {
              var E;
              return {
                tagName: i.tagName,
                textContent: (E = i.textContent) == null ? void 0 : E.substring(0, 200),
                attributes: Array.from(i.attributes).map((m) => ({ name: m.name, value: m.value }))
              };
            });
          }),
          args: [s]
        });
        n({ elements: r[0].result });
        break;
      }
      case "getActivePageContent": {
        const t = await fe(), s = e.data, r = await chrome.scripting.executeScript({
          target: { tabId: t.id },
          func: (o) => o.map((a) => {
            const c = document.querySelector(a);
            return c ? c.outerHTML : null;
          }).filter(Boolean).join(`
`),
          args: [s]
        });
        n({ html: r[0].result });
        break;
      }
      case "host_fetch": {
        const t = e.data, r = await (await fetch(t)).text();
        n({ data: r });
        break;
      }
      case "llm_call": {
        try {
          const { modelAlias: t, options: s, pluginId: r } = e.data;
          console.log("[HOST API] LLM call requested:", { modelAlias: t, pluginId: r });
          const o = r || "ozon-analyzer", a = chrome.runtime.getURL(`public/plugins/${o}/manifest.json`);
          let c;
          try {
            if (c = await fetch(a), !c.ok)
              throw new Error(`Failed to load manifest: ${c.status}`);
          } catch (u) {
            return console.error("[HOST API] Error loading manifest:", u), n({
              error: !0,
              error_message: `Не удалось загрузить настройки плагина ${o}: ${u.message}`
            }), !0;
          }
          const m = ((await c.json()).ai_models || {})[t];
          if (!m)
            return n({
              error: !0,
              error_message: `Модель с алиасом '${t}' не найдена в манифесте плагина`
            }), !0;
          console.log("[HOST API] Using model:", m, "for alias:", t);
          const l = await Ge(m);
          if (!l)
            return n({
              error: !0,
              error_message: `API ключ для модели ${m} не найден`
            }), !0;
          try {
            const u = await ve(m, l, s.prompt || "");
            n({
              response: u
            });
          } catch (u) {
            console.error("[HOST API] AI API error:", u), n({
              error: !0,
              error_message: `Ошибка вызова AI API: ${u.message}`
            });
          }
        } catch (t) {
          console.error("[HOST API] llm_call error:", t), n({
            error: !0,
            error_message: t.message
          });
        }
        break;
      }
      case "get_setting": {
        try {
          const { settingName: t, defaultValue: s, category: r, pluginId: o } = e.data;
          console.log("[HOST API] Get setting requested:", { settingName: t, pluginId: o });
          const a = o || "ozon-analyzer", c = chrome.runtime.getURL(`public/plugins/${a}/manifest.json`);
          let i;
          try {
            if (i = await fetch(c), !i.ok)
              throw new Error(`Failed to load manifest: ${i.status}`);
          } catch (u) {
            return console.error("[HOST API] Error loading manifest:", u), n({
              error: !0,
              error_message: `Не удалось загрузить настройки плагина ${a}: ${u.message}`
            }), !0;
          }
          let l = ((await i.json()).settings || {})[t];
          l === void 0 && (l = s, console.log(`[HOST API] Setting '${t}' not found, using default:`, s)), console.log(`[HOST API] Returning setting '${t}':`, l), n({ value: l });
        } catch (t) {
          console.error("[HOST API] get_setting error:", t), n({
            error: !0,
            error_message: t.message
          });
        }
        break;
      }
      default:
        n({ error: `Unknown command: ${e.command}` });
    }
  } catch (t) {
    n({ error: t.message });
  }
  return !0;
};
chrome.runtime.onMessage.addListener(
  async (e, n, t) => {
    var s, r;
    if ((s = n.url) != null && s.includes("offscreen.html") && (console.log("[background][OFFSCREEN RESPONSE] Message from offscreen received:", e), typeof e == "object" && e !== null && "type" in e)) {
      const o = e;
      if (o.type === "WORKFLOW_LOG")
        return console.log("[background][OFFSCREEN RESPONSE] Relaying workflow log:", o), chrome.runtime.sendMessage({
          type: "LOG_EVENT",
          pluginId: o.pluginId,
          message: o.message,
          level: o.level || "info",
          stepId: o.stepId,
          logData: o.logData,
          pageKey: o.pageKey
        }), !0;
      if (o.type === "WORKFLOW_RESULT") {
        if (console.log("[background][OFFSCREEN RESPONSE] Relaying workflow result:", o), o.pluginId && o.pageKey) {
          const a = {
            role: "plugin",
            content: o.data ? `✅ Результат воркфлоу:
\`\`\`json
${JSON.stringify(o.data, null, 2)}
\`\`\`` : "✅ Воркфлоу выполнен успешно",
            timestamp: Date.now()
          };
          try {
            await w.saveMessage(o.pluginId, b(o.pageKey), a), B(o.pluginId, b(o.pageKey)), console.log("[background][OFFSCREEN RESPONSE] Workflow result saved to chat");
          } catch (c) {
            console.error("[background][OFFSCREEN RESPONSE] Failed to save result to chat:", c);
          }
        }
        return chrome.runtime.sendMessage({
          type: "WORKFLOW_COMPLETED",
          pluginId: o.pluginId,
          result: o.data,
          requestId: o.requestId
        }), !0;
      } else if (o.type === "WORKFLOW_ERROR") {
        if (console.error("[background][OFFSCREEN RESPONSE] Workflow error received:", o), o.pluginId && o.pageKey) {
          const a = {
            role: "plugin",
            content: `❌ Ошибка воркфлоу: ${o.data || "Неизвестная ошибка"}`,
            timestamp: Date.now()
          };
          try {
            await w.saveMessage(o.pluginId, b(o.pageKey), a), B(o.pluginId, b(o.pageKey));
          } catch (c) {
            console.error("[background][OFFSCREEN RESPONSE] Failed to save error to chat:", c);
          }
        }
        return !0;
      } else {
        if (o.type === "HTML_CHUNK_ACK")
          return console.log("[background][CHUNKING] Chunk acknowledgment received:", o), Ve(o), !0;
        if (o.type === "PYODIDE_MESSAGE_SERVICE_WORKER")
          if (console.log("[background][PYODIDE_SERVICE_WORKER] PYODIDE_MESSAGE received from offscreen:", o), o.pluginId && o.pageKey && o.data)
            try {
              const a = {
                role: "plugin",
                content: String(o.data),
                timestamp: o.timestamp || Date.now()
              };
              return await w.saveMessage(o.pluginId, b(o.pageKey), a), B(o.pluginId, b(o.pageKey)), console.log("[background][PYODIDE_SERVICE_WORKER] PYODIDE_MESSAGE relayed to side panel:", {
                pluginId: o.pluginId,
                pageKey: o.pageKey,
                messageLength: (r = a.content) == null ? void 0 : r.length
              }), !0;
            } catch (a) {
              return console.error("[background][PYODIDE_SERVICE_WORKER] Failed to save PYODIDE_MESSAGE to chat:", a), !0;
            }
          else
            return console.warn("[background][PYODIDE_SERVICE_WORKER] Missing required fields in PYODIDE_MESSAGE:", {
              pluginId: !!o.pluginId,
              pageKey: !!o.pageKey,
              data: !!o.data
            }), !0;
      }
    }
    return !1;
  }
);
const fe = async () => {
  const e = await chrome.tabs.query({ currentWindow: !0 }), n = chrome.runtime.getURL("index.html"), t = e.find(
    (s) => {
      var r, o;
      return s.url !== n && (((r = s.url) == null ? void 0 : r.startsWith("http")) || ((o = s.url) == null ? void 0 : o.startsWith("https")));
    }
  );
  if (!t)
    throw new Error("Не найдена подходящая вкладка для анализа (откройте любой сайт в этом же окне).");
  return t;
}, or = async (e) => {
  var t;
  const n = (t = navigator.userAgent.match(/Chrome\/(\d+)/)) == null ? void 0 : t[1];
  chrome.runtime.getURL("pyodide/pyodide.js"), console.log("[TEST_PYODIDE_DIRECT] Chrome version:", n);
  try {
    if (console.log("[TEST_PYODIDE_DIRECT] Checking Pyodide availability..."), X()) {
      console.log("[TEST_PYODIDE_DIRECT] Using offscreen document execution");
      try {
        await ee();
        const s = {
          type: "TEST_PYODIDE_DIRECT_EXEC",
          pythonCode: e.pythonCode || 'print("Hello from Pyodide!")',
          requestId: `test_pyodide_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          timestamp: Date.now()
        };
        console.log("[TEST_PYODIDE_DIRECT] Sending to offscreen:", s);
        const r = await chrome.runtime.sendMessage(s);
        return {
          success: (r == null ? void 0 : r.success) || !1,
          result: (r == null ? void 0 : r.result) || null,
          error: (r == null ? void 0 : r.error) || null,
          timestamp: Date.now(),
          chromeVersion: n
        };
      } catch (s) {
        return console.error("[TEST_PYODIDE_DIRECT] Offscreen execution failed:", s), {
          success: !1,
          error: `Offscreen execution error: ${s.message}`,
          timestamp: Date.now(),
          chromeVersion: n
        };
      }
    } else
      return console.log("[TEST_PYODIDE_DIRECT] Chrome < 109 detected, using fallback mode"), {
        success: !1,
        result: {
          chromeVersion: n,
          pyodideAvailable: !1,
          offscreenSupported: !1,
          message: "Pyodide недоступен для данной версии Chrome"
        },
        error: "Pyodide requires Chrome 109+ with Offscreen Document API support",
        timestamp: Date.now(),
        chromeVersion: n
      };
  } catch (s) {
    return console.error("[TEST_PYODIDE_DIRECT] Test execution failed:", s), {
      success: !1,
      error: `Test execution error: ${s.message}`,
      timestamp: Date.now(),
      chromeVersion: n
    };
  }
};
chrome.runtime.onConnect.addListener((e) => {
  console.log("[background] Port connected:", e.name), e.onMessage.addListener(async (n) => {
    if (n.type === "GET_PLUGINS")
      try {
        const t = await ae(), s = await q.get(), r = await Promise.all(
          t.map(async (o) => ({
            ...o,
            settings: s[o.id] || { enabled: !0, autorun: !1 }
          }))
        );
        e.postMessage({ type: "PLUGINS_RESULT", plugins: r });
      } catch (t) {
        e.postMessage({ type: "PLUGINS_ERROR", error: t.message });
      }
  });
});
chrome.tabs.onUpdated.addListener(async (e, n, t) => {
  if (n.status === "complete" && t.url && (t.url.startsWith("http") || t.url.startsWith("https")))
    try {
      const s = await ae(), r = await q.get();
      console.log("[background] Tab updated, checking plugins for autorun:", t.url);
      for (const o of s) {
        const a = r[o.id] || { enabled: !0, autorun: !1 };
        a.enabled && a.autorun && await Ze(o.id);
      }
    } catch (s) {
      console.error("[background] Error in autorun handler:", s);
    }
});
He.get().then((e) => {
  console.log("[background] Theme loaded:", e);
});
console.log("[background] 🚀 =============================================");
console.log("[background] 🚀 EXTENSION INITIALIZATION DIAGNOSTIC REPORT");
console.log("[background] 🚀 =============================================");
console.log("[background] 📊 System Information:");
console.log("[background]   - Timestamp:", (/* @__PURE__ */ new Date()).toISOString());
console.log("[background]   - User-Agent:", navigator.userAgent);
var pe;
console.log("[background]   - Chrome version:", ((pe = navigator.userAgent.match(/Chrome\/(\d+)/)) == null ? void 0 : pe[1]) || "Unknown");
console.log("[background]   - Extension ID:", chrome.runtime.id);
const Ie = X();
console.log("[background] 📊 Offscreen API Analysis:");
console.log("[background]   - Offscreen API supported:", Ie);
if (!Ie)
  console.warn("[background] ⚠️ LEGACY CHROME DETECTED (< 109):"), console.warn("[background]   - Offscreen API is not available in this Chrome version"), console.warn("[background]   - Fallback workflow execution mode will be used"), console.warn("[background]   - To enable full functionality, please update Chrome to version 109+"), console.warn("[background]   - See: https://developer.chrome.com/docs/extensions/migrating-to-service-workers/"), console.warn("[background] ❌ PRODUCTION IMPACT: Pyodide workflows will fail with legacy fallback");
else {
  console.log("[background] ✅ Modern Chrome detected (>= 109)"), console.log("[background]   - Full offscreen document workflow available"), console.log("[background]   - Pyodide execution via workers expected to work");
  try {
    console.log("[background] 🔍 Runtime Context Verification:"), console.log("[background]   - Runtime permissions check..."), (async () => {
      try {
        const e = await chrome.offscreen.hasDocument();
        console.log("[background]   - Offscreen document exists on startup:", e), e || (console.log("[background]   - Creating initial offscreen document..."), await ee(), console.log("[background]   - Initial offscreen document created successfully"));
      } catch (e) {
        console.error("[background] ❌ Critical: Failed to initialize offscreen document on startup:", e), console.error("[background]   - This may indicate manifest/permission issues");
      }
    })();
  } catch (e) {
    console.error("[background] ❌ Runtime verification failed:", e);
  }
}
console.log("[background] 📈 Available Chrome APIs:", typeof chrome < "u" ? Object.keys(chrome).filter((e) => typeof chrome[e] == "object").join(", ") : "None");
console.log("[background] 🚀 =============================================");
console.log("[background] Background script fully loaded and ready");
console.log("[background] Extension ID:", chrome.runtime.id);
console.log("[background] Available APIs:", {
  runtime: typeof chrome.runtime,
  tabs: typeof chrome.tabs,
  storage: typeof chrome.storage,
  sidePanel: typeof chrome.sidePanel,
  scripting: typeof chrome.scripting,
  offscreen: typeof chrome.offscreen
});
console.log("[background][OFFSCREEN DIAGNOSTIC] Detailed Offscreen API analysis:");
console.log("[background][OFFSCREEN DIAGNOSTIC]   chrome object:", typeof chrome);
console.log("[background][OFFSCREEN DIAGNOSTIC]   chrome.offscreen:", typeof chrome.offscreen);
chrome.offscreen ? (console.log("[background][OFFSCREEN DIAGNOSTIC]   chrome.offscreen properties:", Object.keys(chrome.offscreen)), console.log("[background][OFFSCREEN DIAGNOSTIC]   hasDocument:", typeof chrome.offscreen.hasDocument), console.log("[background][OFFSCREEN DIAGNOSTIC]   createDocument:", typeof chrome.offscreen.createDocument)) : console.log("[background][OFFSCREEN DIAGNOSTIC]   chrome.offscreen is undefined!");
console.log("[background][OFFSCREEN DIAGNOSTIC] Global context info:");
console.log("[background][OFFSCREEN DIAGNOSTIC]   window:", typeof window);
console.log("[background][OFFSCREEN DIAGNOSTIC]   self:", typeof self);
console.log("[background][OFFSCREEN DIAGNOSTIC]   globalThis:", typeof globalThis);
console.log("[background] Edit chrome-extension/src/background/index.ts and save to reload.");
